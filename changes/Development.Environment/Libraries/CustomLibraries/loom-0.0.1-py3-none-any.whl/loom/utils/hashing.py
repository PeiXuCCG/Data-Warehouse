from pyspark.sql import DataFrame
from pyspark.sql.functions import sha2, concat_ws, lit


def compute_sha2_256(df: DataFrame, cols: list[str], new_col: str) -> DataFrame:
    """
    Compute a SHA2-256 hash from multiple columns and store it in a new column.

    :param df: Input PySpark DataFrame
    :param cols: List of column names to concatenate before hashing
    :param new_col: Name of the new column to store the hash
    :return: DataFrame with the new hash column added
    :raises ValueError: if cols is empty
    """
    if not cols:
        raise ValueError("Column list for hashing cannot be empty.")

    return df.withColumn(
        new_col,
        sha2(concat_ws("|", *[df[c] for c in cols]), 256)
    )


def sha2_const(df: DataFrame, new_col: str, value: str) -> DataFrame:
    """
    Compute a SHA2-256 hash for a constant string value and store it in a new column.

    :param df: Input PySpark DataFrame
    :param new_col: Name of the new column to store the hash
    :param value: String value to hash (e.g., '-1' for missing keys)
    :return: DataFrame with the constant hash column added
    """
    return df.withColumn(new_col, sha2(concat_ws("|", lit(value)), 256))
