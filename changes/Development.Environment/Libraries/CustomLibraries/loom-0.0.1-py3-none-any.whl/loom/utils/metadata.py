from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import TimestampType

def add_ingestion_metadata(df: DataFrame, add_effectivity: bool) -> DataFrame:
    """
    Adds standardized ingestion and optional effectivity metadata columns
    to a PySpark DataFrame for use in Loom data pipelines.

    This function ensures that every record includes:
      - ingestion_timestamp: The UTC time the record was ingested.
      - effectivity_start_date (optional): When the record became valid.
      - effectivity_end_date (optional): When the record is no longer valid (NULL by default).

    Args:
        df (DataFrame): The input Spark DataFrame to enrich.
        add_effectivity (bool): If True, adds effectivity start/end columns
                                for slowly changing or time-tracked records.

    Returns:
        DataFrame: The same DataFrame with ingestion and (optionally) effectivity metadata columns.

    Example:
        >>> df = add_ingestion_metadata(df, add_effectivity=True)
        >>> df.select("ingestion_timestamp", "effectivity_start_date", "effectivity_end_date").show()
    """
    if add_effectivity:
        df = (
            df.withColumn("effectivity_start_date", F.current_timestamp())
              .withColumn("effectivity_end_date", F.lit(None).cast(TimestampType()))
        )

    df = df.withColumn("ingestion_timestamp", F.current_timestamp())
    return df

def add_source_metadata(df: DataFrame, source_system: str) -> DataFrame:
    """
    Adds source system and entity metadata to a Spark DataFrame, including the
    file name from which the data originated.

    This is typically used in the *raw/staging* zone to preserve lineage
    information — i.e., where the data came from.

    Args:
        df (DataFrame): The input Spark DataFrame.
        source_system (str): Name of the source system (e.g., "Business Central").
       
    Returns:
        DataFrame: A DataFrame enriched with the following columns:
            - `source_system`: Literal value provided by `source_system`.
            - `source_file`: The full file path of the input data file, captured using `input_file_name()`.

    Example:
        >>> df = spark.read.csv("s3://data/raw/customers.csv", header=True)
        >>> df = add_source_metadata(df, "BC", "Contoso Ltd")
        >>> df.select("source_system", "$Company", "source_file").show(1)
    """

    # Add a column indicating which system the data originated from
    df = df.withColumn("source_system", F.lit(source_system))

    # Capture the full path of the input file for traceability and auditing
    df = df.withColumn("source_file", F.input_file_name())

    return df