from typing import List, Tuple
from pyspark.sql import DataFrame
from .base_table import BaseTable
from .table_type import TableType
from loom.utils.metadata import add_ingestion_metadata
from typing import Callable

import pyspark.sql.functions as F

class MasterLinkedTable(BaseTable):
    """
    MasterLinkedTable extends KeyedTable to support linking one dataset to multiple
    master datasets (e.g. Product Master, Customer Master, etc.).

    Each master link is a tuple of:
        (alias, master_df, business_key, master_key_col)

    Example:
        sales_table = MasterLinkedTable(
            name="sales_order_line",
            df=sales_df,
            business_keys=["salesorderlineid"],
            primary_keys=["salesorderlineid","lineno"],
            master_links=[
                ("product", product_master_df, "productcode", "proudct_hk", [{"field": "field2"}])
            ]
        )
    """

    def __init__(
        self,
        name: str,
        df: DataFrame,
        schema_evolution: bool,
        target_path: str,
        target_db: str = None,
        target_schema: str = None,
        transform: Callable = None,
        business_keys: List[str] = [],
        primary_keys: List[str] = [],
        master_links: List[Tuple[str, DataFrame, str, str]] = [],
    ):
        super().__init__(name, TableType.MASTERLINKED, df, schema_evolution,  target_path=target_path, target_schema=target_schema, target_db=target_db)
        self.master_links = master_links
        self.transform = transform
        self.primary_keys = primary_keys
        self.business_keys = business_keys

    def prepare(self) -> DataFrame:
        """
        Prepare the table for ingestion:
        - Join all master mappings
        - Replace missing master keys with sha2('-1', 256)
        - Add metadata fields for audit and effectivity tracking
        """
        df = self.df

        for master_alias, master_df, business_key, master_key_col, materialized_fields in self.master_links:
            # 1️⃣ Prepare lookup dataframe (only needed cols)
            lookup_cols = [business_key, master_key_col] + [list(f.values())[0] for f in materialized_fields]
            lookup_df = master_df.select(*lookup_cols)

            # 2️⃣ Build rename mapping for descriptive fields
            rename_map = {}
            for mapping in materialized_fields:
                for target_field, source_field in mapping.items():
                    rename_map[source_field] = target_field  # e.g. "name" -> "ProductName"

            # 3️⃣ Rename descriptive columns
            for src_col, tgt_col in rename_map.items():
                lookup_df = lookup_df.withColumnRenamed(src_col, tgt_col)

            # 4️⃣ Join master table to base df
            df = df.join(lookup_df, on=business_key, how="left")

            # 5️⃣ Materialize master key (e.g. product_master_hk = product_hk)
            df = df.withColumn(master_alias, F.col(master_key_col))

            # 6️⃣ Replace missing master keys with sha2('-1', 256)
            df = df.withColumn(
                master_alias,
                F.when(F.col(master_alias).isNotNull(), F.col(master_alias))
                .otherwise(F.sha2(F.lit("-1"), 256))
            )

            # 7️⃣ Only materialize/update lookup fields if the master key exists
            for mapping in materialized_fields:
                for target_field, _ in mapping.items():
                    df = df.withColumn(
                        target_field,
                        F.when(F.col(master_alias) != F.sha2(F.lit("-1"), 256), F.col(target_field))
                        .otherwise(F.col(target_field))  # keep original if missing
                    )

        # 8️⃣ Add ingestion and effectivity metadata
        df = add_ingestion_metadata(df, True)

        self.df = df
        return df
    
    def write_ingestion_log(self):
        pass

    def get_partition_keys(self):
        return self.business_keys

    def set_tbl_properties(self):
        self.spark.sql(f"""
            ALTER TABLE {self.target_schema}.{self.target_db}.{self.name}
            SET TBLPROPERTIES (
            'primaryKeys' = {self.primary_keys},
            'masterKeys' = {[m[0] for m in self.master_links]}
            'lastUpdatedBy' = 'FabricPipeline'
            )
            """)