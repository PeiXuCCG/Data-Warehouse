from pyspark.sql import DataFrame
from pyspark.sql.functions import current_timestamp
from loom.tables.base_table import BaseTable
from loom.tables.table_type import TableType
from loom.utils.metadata import add_ingestion_metadata, add_source_metadata
from typing import  Callable

class PlainTable(BaseTable):
    """
    Represents a simple, non-keyed dataset — typically used for staging or raw zones.

    PlainTable should not:
      - generate primary keys
      - deduplicate records

    It simply validates the DataFrame and provides a consistent interface for ingestion.

    Example:
        raw_table = PlainTable(
            target_schema="dbo",
            target_db="test",
            name="stg_sales_raw",
            source_system="awesome_software",
            target_path="/tmp/stg_sales_raw",
            df=spark.read.option("header", True).csv("/data/staging/sales.csv"),
            write_method="overwrite",
            cleanse_function=cleanse
        )
    """

    def __init__(self, name: str, source_system: str,  df: DataFrame,  target_path: str, write_method: str, target_schema: str, target_db: str,  cleanse_function: Callable):
        super().__init__(name, TableType.PLAIN, df, target_path=target_path, write_method=write_method, target_schema=target_schema, target_db=target_db )
        self.source_system = source_system
        self.cleanse_function = cleanse_function


    def prepare(self) -> DataFrame:
        """
        Perform minimal validation on the DataFrame before ingestion.
        This step ensures the dataset is not empty and has valid columns.
        """
        df = self.df
        # Basic validation: ensure non-empty schema
        if len(df.columns) == 0:
            raise ValueError(f"PlainTable '{self.name}' has no columns defined")
        
        # run the cleansing function that should clean up data types and standard formats ie: dates etc.
        if self.cleanse_function is not None:
            df = self.cleanse_function(self.df)

        # adding specific source to raw metadata
        df = add_source_metadata(df, self.source_system)

        # Adding ingestion timestamp          
        df = add_ingestion_metadata(df, False)

        # Optionally: add a count check or schema validation here later
        self.df = df
        return df
    
 
    def set_tbl_properties(self):
        return

    def get_partition_keys(self):
        return []
    
    def write_ingestion_log(self):
        (
            self.df.select("source_file","ingestion_timestamp").distinct()
                .write.mode("append").saveAsTable("dbo.ingestion_log")
        )
        
        