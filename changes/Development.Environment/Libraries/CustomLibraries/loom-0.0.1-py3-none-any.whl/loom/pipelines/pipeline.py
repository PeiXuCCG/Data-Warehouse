from datetime import datetime
from typing import List, Optional
from loom.tables.base_table import BaseTable
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from delta.tables import DeltaTable


class Pipeline:
    """
    The Loom Pipeline class orchestrates data ingestion and transformation.

    It coordinates a collection of Loom tables (PlainTable, KeyedTable, MasterLinkedTable)
    and manages end-to-end execution for ingestion pipelines.

    Features:
      - Validation of all tables before execution
      - Dry-run mode (no writes, only validation/logging)
      - Batch ID tagging for traceability
      - Flexible structure for independent domain pipelines (e.g., sales, customers)
      - transform function
    """

    def __init__(
        self,
        name: str,
        tables: List[BaseTable],
        dry_run: bool = False,
        batch_id: Optional[str] = None,
        target_schema: Optional[str] = None,
        target_db: Optional[str] = None
    ):
        """
        :param name: Name of the pipeline (e.g. 'sales_ingestion')
        :param tables: List of BaseTable instances (PlainTable, KeyedTable, etc.)
        :param dry_run: If True, validation and logs are run, but no data is written
        :param batch_id: Optional identifier for batch loads (defaults to current timestamp)
        :param target_schema: Optional for the catalog (<lakehouse name>) of the audit_log
        :param target_db: Optional for the schema (dbo) for the audit_log
        
        """
        self.name = name
        self.tables = tables
        self.dry_run = dry_run
        self.batch_id = batch_id or datetime.utcnow().strftime("%Y%m%d%H%M%S")
        self._validated = False
        self.target_schema = target_schema,
        self.target_db = target_db

    # ================================================================
    # Core methods
    # ================================================================

    def validate(self) -> bool:
        """
        Validates all tables in the pipeline by:
          - Checking for valid schemas
          - Running table-specific preparation logic
        """
        print(f"🔍 Validating pipeline '{self.name}' (Batch ID: {self.batch_id})")

        for table in self.tables:
            print(f"  • Validating table '{table.name}'...")
            try:
                table.validate_schema()
                table.prepare()  # Each subclass handles its own logic
                print(f"    ✅ Table '{table.name}' validated successfully.")
            except Exception as e:
                print(f"    ❌ Validation failed for table '{table.name}': {e}")
                raise

        self._validated = True
        print(f"✅ Pipeline '{self.name}' validation completed.\n")
        return True

    def execute(self):
        """
        Executes the ingestion pipeline:
          - Validates if not already done
          - Applies batch tagging
          - Saves output unless in dry-run mode
        """
        print(f"🚀 Executing pipeline '{self.name}' (Dry run: {self.dry_run})")

        if not self._validated:
            self.validate()

        for table in self.tables:
            print(f"⚙️ Processing table '{table.name}'...")

            # Apply batch ID as a column for traceability
            table.df = table.df.withColumn("batch_id", lit(self.batch_id))

            if self.dry_run:
                print(f"    💡 Dry run mode: skipping save for '{table.name}'.")
                table.preview(5)
            else:
                if not table.target_path:
                    raise ValueError(
                        f"❌ Table '{table.name}' has no target_path defined — cannot save."
                    )
                table.write()
                self.write_audit_log(self.name, self.batch_id, table.count(), "success", self.target_schema, self.target_db)

        print(f"🏁 Pipeline '{self.name}' execution complete. (Dry run: {self.dry_run})")

    # ================================================================
    # Utilities
    # ================================================================
    def write_audit_log(
        pipeline_name: str,
        batch_id: str,
        rows: int,
        status: str,
        target_schema: str = "dbo",
        target_db: str = "audit_logs"
    ) -> None:
        """
        Write a structured audit log entry for a pipeline execution.
        
        Args:
            spark (SparkSession): Active Spark session.
            pipeline_name (str): Name of the pipeline being executed.
            batch_id (str): Unique batch identifier (usually a timestamp or UUID).
            rows (int): Number of records processed.
            status (str): Execution status ("success", "failed", etc.).
            audit_path (str): Delta/Parquet path for storing audit logs.
        """

        spark = SparkSession.builder.appName(pipeline_name).getOrCreate()
        # ✅ Create a DataFrame for the audit entry
        audit_df = spark.createDataFrame(
            [
                (
                    datetime.utcnow().isoformat(),
                    pipeline_name,
                    batch_id,
                    rows,
                    status
                )
            ],
            ["timestamp", "pipeline_name", "batch_id", "rows", "status"]
        )

        # ✅ Ensure audit directory exists (for non-Delta fallback)

        try:
            # Try Delta Lake first
            audit_df.write.format("delta").option().mode("append").saveAsTable(f"{target_schema}.{target_db}.audit_logs")
            print(f"🧾 Audit log written for Delta : {target_schema}.{target_db}.audit_logs")
        except Exception as e:
            # Fallback to Parquet if Delta not available
            print(f"⚠️ Delta not available, Error: {e}")
            

    def summary(self) -> None:
        """Displays a summary of all tables in the pipeline."""
        print(f"\n📊 Pipeline Summary: {self.name}")
        print(f"Batch ID: {self.batch_id}")
        print(f"Dry Run: {self.dry_run}")
        print(f"Number of tables: {len(self.tables)}\n")

        for table in self.tables:
            print(f"  • {table.name}: {len(table.df.columns)} columns, {table.count()} rows")

    def get_table(self, name: str) -> Optional[BaseTable]:
        """Retrieve a table by name."""
        for table in self.tables:
            if table.name == name:
                return table
        return None
