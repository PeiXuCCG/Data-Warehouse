import pytest
from unittest.mock import patch, MagicMock
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import StructType, StructField, StringType
from loom.tables.keyed_table import KeyedTable


@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("KeyedTableTest").getOrCreate()


def test_prepare_adds_hash_and_metadata(spark):
    # Create a simple input DataFrame
    df = spark.createDataFrame(
        [
            (1, "Alice"),
            (2, "Bob"),
        ],
        ["CustomerID", "Name"]
    )

    # Mock add_ingestion_metadata and assert_no_duplicates
    with patch("loom.tables.keyed_table.add_ingestion_metadata", side_effect=lambda df, _: df) as mock_meta, \
         patch("loom.tables.keyed_table.assert_no_duplicates") as mock_dupes:
        
        table = KeyedTable(
            target_db="public",
            target_schema="dbo",
            name="customers",
            schema_evolution=False,
            df=df,
            target_path="/tmp",
            business_keys=["CustomerID"],
            primary_keys=["CustomerID"],
            transform=None,
            deduplicate=None
        )

        result_df = table.prepare()
        columns = result_df.columns

        # Check primary key hash added
        assert "customers_hk" in columns

        # Verify mocks called
        mock_meta.assert_called_once()
        mock_dupes.assert_called_once()

        # Ensure DataFrame contents unchanged except for hash
        assert result_df.filter(F.col("customers_hk").isNotNull()).count() == df.count()


def test_prepare_raises_for_missing_primary_key(spark):
    df = spark.createDataFrame(
        [(1, "Alice")],
        ["WrongID", "Name"]
    )

    table = KeyedTable(
        target_schema="dbo",
        target_db="public",
        name="customers",
        schema_evolution=False,
        df=df,
        target_path="/tmp",
        business_keys=["WrongID"],
        primary_keys=["CustomerID"],  # missing in DF
        transform=None,
        deduplicate=None
    )

    with pytest.raises(ValueError, match="Primary key column 'CustomerID' not found"):
        table.prepare()



def test_apply_scd_type2_handles_changes(spark):
    # Define explicit schemas for both DataFrames
    existing_schema = StructType([
        StructField("customers_hk", StringType(), False),
        StructField("Name", StringType(), True),
        StructField("effectivity_start_date", StringType(), True),
        StructField("effectivity_end_date", StringType(), True),
    ])

    incoming_schema = StructType([
        StructField("customers_hk", StringType(), False),
        StructField("Name", StringType(), True),
    ])

    # Create typed DataFrames
    existing_df = spark.createDataFrame(
        [
            ("1", "Alice", "2024-01-01", None),
            ("2", "Bob", "2024-01-01", None),
        ],
        schema=existing_schema
    )

    incoming_df = spark.createDataFrame(
        [
            ("1", "Alicia"),   # Changed name
            ("2", "Bob"),      # Unchanged
            ("3", "Charlie"),  # New record
        ],
        schema=incoming_schema
    )

    table = KeyedTable(
        target_schema="dbo",
        target_db="public",
        name="customers",
        schema_evolution=False,
        df=incoming_df,
        target_path="/tmp",
        business_keys=["customers_hk"],
        primary_keys=["customers_hk"],
        transform=None,
        deduplicate=None
    )

    result = table.apply_scd_type2(existing_df, incoming_df)

    # Ensure key columns exist
    assert set(["effectivity_start_date", "effectivity_end_date"]).issubset(result.columns)

    # Collect and sanity check
    result_data = [r.asDict() for r in result.collect()]

    # Verify Alicia appears (updated record)
    assert any(r["Name"] == "Alicia" for r in result_data)
    # Verify Charlie appears (new record)
    assert any(r["Name"] == "Charlie" for r in result_data)
    # Verify some records are end-dated
    assert any(r["effectivity_end_date"] is not None for r in result_data)
