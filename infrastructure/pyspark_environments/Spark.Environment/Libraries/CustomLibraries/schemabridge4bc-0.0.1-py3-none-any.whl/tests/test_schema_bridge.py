import pytest
import pandas as pd

from schemabridge4bc.schemabridge.bridgeschemas import transform_using_schema_bridge

# --- Mock mapping modules ---

class MockXeroMapping:
    objects = {
        "Invoices": {"InvoiceID": "invoice_id", "CustomerName": "customer_name"},
        "Payments": {"PaymentID": "payment_id"}
    }

class MockMyobMapping:
    objects = {
        "Sales": {"SaleID": "sale_id", "Total": "total_amount"}
    }

# Mock mapping_imports (simulate your real list)
mapping_imports = [
    {"name": "Xero", "module": MockXeroMapping},
    {"name": "Myob", "module": MockMyobMapping}
]


# --- Monkeypatch mapping_imports inside schema_bridge ---

@pytest.fixture(autouse=True)
def patch_mapping_imports(monkeypatch):
    monkeypatch.setattr("schemabridge4bc.schemabridge.bridgeschemas.mapping_imports", mapping_imports)


# --- Tests ---

def test_transform_using_schema_bridge_success():
    df = pd.DataFrame({
        "InvoiceID": [1, 2],
        "CustomerName": ["Alice", "Bob"]
    })

    df_result = transform_using_schema_bridge("Xero", "Invoices", df)

    expected_columns = ["invoice_id", "customer_name"]
    assert list(df_result.columns) == expected_columns
    assert df_result.shape == (2, 2)


def test_transform_using_schema_bridge_unknown_source_system():
    df = pd.DataFrame({"col": [1]})
    with pytest.raises(ValueError, match="Source system 'Unknown' not found"):
        transform_using_schema_bridge("Unknown", "Invoices", df)


def test_transform_using_schema_bridge_unknown_table_name():
    df = pd.DataFrame({"col": [1]})
    with pytest.raises(ValueError, match="Table 'Nonexistent' not found"):
        transform_using_schema_bridge("Xero", "Nonexistent", df)


def test_transform_using_schema_bridge_partial_column_match():
    df = pd.DataFrame({"PaymentID": [1], "Other": [2]})
    df_result = transform_using_schema_bridge("Xero", "Payments", df)

    # Only PaymentID should be renamed
    assert "payment_id" in df_result.columns
    assert "Other" in df_result.columns
