import pytest
import pandas as pd
import types
from schemabridge4bc.schemabridge.bridgeschemas import normalize_column_name, transform_using_schema_bridge

# ----- Unit tests for normalize_column_name -----

@pytest.mark.parametrize("input_name,expected", [
    ("Invoice Date", "invoicedate"),
    ("Invoice Date (Ex)", "invoicedateex"),
    ("Total$", "total"),
    ("Total  $  Amount", "totalamount"),
    ("  Leading Spaces  ", "leadingspaces"),
    ("Special*&^%Chars", "specialchars"),
    ("___Already__Clean__", "alreadyclean"),
])
def test_normalize_column_name(input_name, expected):
    assert normalize_column_name(input_name) == expected


# ----- Unit tests for transform_using_schema_bridge -----

def test_transform_using_schema_bridge_renames_correctly(monkeypatch):
    # Mock mapping_imports
    mock_module = types.SimpleNamespace(objects={
        "Invoices": {
            "Invoice Date": "Invoice Date (Ex)",
            "Total$": "Total $ Amount"
        }
    })
    mapping_imports = [{"name": "Xero", "module": mock_module}]

    # Inject mapping_imports into the global namespace of the tested function
    monkeypatch.setitem(transform_using_schema_bridge.__globals__, "mapping_imports", mapping_imports)

    # Sample DataFrame
    df = pd.DataFrame({
        "Invoice Date": ["2025-11-13"],
        "Total$": [100]
    })

    result = transform_using_schema_bridge("Xero", "Invoices", df)

    # Expect columns normalized and renamed
    assert list(result.columns) == ["invoicedateex", "totalamount"]
    assert result.iloc[0, 1] == 100


def test_transform_using_schema_bridge_source_not_found(monkeypatch):
    mapping_imports = [{"name": "BC", "module": None}]
    monkeypatch.setitem(transform_using_schema_bridge.__globals__, "mapping_imports", mapping_imports)
    df = pd.DataFrame()
    with pytest.raises(ValueError, match="Source system 'Xero' not found"):
        transform_using_schema_bridge("Xero", "Invoices", df)


def test_transform_using_schema_bridge_table_not_found(monkeypatch):
    mock_module = types.SimpleNamespace(objects={})
    mapping_imports = [{"name": "Xero", "module": mock_module}]
    monkeypatch.setitem(transform_using_schema_bridge.__globals__, "mapping_imports", mapping_imports)
    df = pd.DataFrame()
    with pytest.raises(ValueError, match="Table 'Invoices' not found"):
        transform_using_schema_bridge("Xero", "Invoices", df)


# ----- Integration test: both functions together -----

def test_integration_normalization_and_transform(monkeypatch):
    mock_module = types.SimpleNamespace(objects={
        "Payments": {
            "Amount Paid": "Amount (AUD)",
            "Date Paid": "Date Paid!"
        }
    })
    mapping_imports = [{"name": "MYOB", "module": mock_module}]
    monkeypatch.setitem(transform_using_schema_bridge.__globals__, "mapping_imports", mapping_imports)

    df = pd.DataFrame({
        "Amount Paid": [500],
        "Date Paid": ["2025-11-13"]
    })

    result = transform_using_schema_bridge("MYOB", "Payments", df)

    # Check that normalize_column_name() effects show up in column names
    assert list(result.columns) == ["amountaud", "datepaid"]
    assert result.iloc[0].to_dict() == {"amountaud": 500, "datepaid": "2025-11-13"}
