import pytest
import types
from pyspark.sql import SparkSession
from pyspark.sql.types import StructField, StructType, StringType, IntegerType

from schemabridge4bc.schemabridge.bridgeschemas import (
    normalize_column_name,
    transform_using_schema_bridge
)

# -------------------- Spark Session Fixture --------------------
@pytest.fixture(scope="module")
def spark():
    return (
        SparkSession.builder
        .master("local[1]")
        .appName("SchemaBridgeTests")
        .getOrCreate()
    )

# -------------------- Empty DF Fixture --------------------
@pytest.fixture(scope="module")
def empty_dataframe(spark):
    schema = StructType([
        StructField("invoicedate", StringType(), True),
        StructField("amount", StringType(), True)
    ])
    return spark.createDataFrame([], schema)

# -------------------- normalize_column_name tests --------------------
@pytest.mark.parametrize("input_name,expected", [
    ("Invoice Date", "invoicedate"),
    ("Invoice Date (Ex)", "invoicedateex"),
    ("Total$", "total"),
    ("Total  $  Amount", "totalamount"),
    ("  Leading Spaces  ", "leadingspaces"),
    ("Special*&^%Chars", "specialchars"),
    ("___Already__Clean__", "alreadyclean"),
])
def test_normalize_column_name(input_name, expected):
    assert normalize_column_name(input_name) == expected

# -------------------- transform_using_schema_bridge tests --------------------
def test_transform_using_schema_bridge_renames_correctly(monkeypatch, spark):
    mock_module = types.SimpleNamespace(objects={
        "Invoices": [
            ("ID", "ID"),
            ("Invoice Date", "Invoice Date Ex"),
            ("Total$", "Total $ Amount")
        ]
    })

    def mock_builder():
        return [{"name": "Xero", "module": mock_module}]

    monkeypatch.setattr(
        "schemabridge4bc.schemabridge.bridgeschemas.build_mapping_imports_from_mappings_folder",
        mock_builder
    )

    schema = StructType([
        StructField("ID", StringType()),
        StructField("Invoice Date", StringType()),
        StructField("Total$", IntegerType())
    ])

    df = spark.createDataFrame(
        [(1, "2025-11-13", 100)],
        schema=schema
    )

    result = transform_using_schema_bridge(
        spark,
        "Xero",
        "Invoices",
        df,
        source_key="id"
    )

    assert list(result.columns) == [
        "unmapped",
        "source_system",
        "id",
        "invoicedateex",
        "totalamount"
    ]

    assert result.collect()[0]["totalamount"] == int("100")

# -------------------- Source not found --------------------
def test_transform_using_schema_bridge_source_not_found(monkeypatch, spark, empty_dataframe):
    monkeypatch.setattr(
        "schemabridge4bc.schemabridge.bridgeschemas.build_mapping_imports_from_mappings_folder",
        lambda: []
    )

    with pytest.raises(ValueError, match="Source system 'Xero' not found"):
        transform_using_schema_bridge(
            spark,
            "Xero",
            "Invoices",
            empty_dataframe,
            "name"
        )

# -------------------- Table not found --------------------
def test_transform_using_schema_bridge_table_not_found(monkeypatch, spark, empty_dataframe):
    mock_module = types.SimpleNamespace(objects={})

    monkeypatch.setattr(
        "schemabridge4bc.schemabridge.bridgeschemas.build_mapping_imports_from_mappings_folder",
        lambda: [{"name": "Xero", "module": mock_module}]
    )

    with pytest.raises(ValueError, match="Table 'Invoices' not found"):
        transform_using_schema_bridge(
            spark,
            "Xero",
            "Invoices",
            empty_dataframe,
            "name"
        )

# -------------------- PySpark function mapping (coalesce) --------------------
def test_transform_using_schema_bridge_coalesce(monkeypatch, spark):
    mock_module = types.SimpleNamespace(objects={
        "Customers": [
            ("Id", "Id"),
            ("coalesce(Location, Name)", "Name")
        ]
    })

    monkeypatch.setattr(
        "schemabridge4bc.schemabridge.bridgeschemas.build_mapping_imports_from_mappings_folder",
        lambda: [{"name": "CRM", "module": mock_module}]
    )

    schema = StructType([
        StructField("Id", StringType()),
        StructField("Location", StringType()),
        StructField("Name", StringType()),
    ])

    df = spark.createDataFrame([
        ("1", "Melbourne", None),
        ("2", None, "Sydney"),
        ("3", "Bendigo", None),
    ], schema=schema)

    result = transform_using_schema_bridge(
        spark,
        "CRM",
        "Customers",
        df,
        source_key="id"
    )

    rows = result.select("name").collect()

    assert rows[0]["name"] == "Bendigo"
    assert rows[1]["name"] == "Melbourne"
    assert rows[2]["name"] == "Sydney"
