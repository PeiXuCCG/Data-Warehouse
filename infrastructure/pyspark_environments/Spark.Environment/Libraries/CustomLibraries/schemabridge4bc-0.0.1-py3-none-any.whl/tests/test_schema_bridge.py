import pytest
import pandas as pd
import types
from pyspark.sql import SparkSession
from pyspark.sql.types import StructField, StructType, StringType, IntegerType

from schemabridge4bc.schemabridge.bridgeschemas import (
    normalize_column_name,
    transform_using_schema_bridge
)


# -------------------- Spark Session Fixture --------------------
@pytest.fixture(scope="module")
def spark():
    return (
        SparkSession.builder
        .master("local[1]")
        .appName("SchemaBridgeTests")
        .getOrCreate()
    )


# -------------------- Empty DF Fixture --------------------
@pytest.fixture(scope="module")
def empty_dataframe(spark):
    schema = StructType([
        StructField("invoicedate", StringType(), True),
        StructField("amount", StringType(), True)
    ])
    return spark.createDataFrame([], schema)


# -------------------- normalize_column_name tests --------------------

@pytest.mark.parametrize("input_name,expected", [
    ("Invoice Date", "invoicedate"),
    ("Invoice Date (Ex)", "invoicedateex"),
    ("Total$", "total"),
    ("Total  $  Amount", "totalamount"),
    ("  Leading Spaces  ", "leadingspaces"),
    ("Special*&^%Chars", "specialchars"),
    ("___Already__Clean__", "alreadyclean"),
])
def test_normalize_column_name(input_name, expected):
    assert normalize_column_name(input_name) == expected


# -------------------- transform_using_schema_bridge tests --------------------

def test_transform_using_schema_bridge_renames_correctly(monkeypatch, spark):
    mock_module = types.SimpleNamespace(objects={
        "Invoices": {
            "Invoice Date": "Invoice Date (Ex)",
            "Total$": "Total $ Amount"
        }
    })

    monkeypatch.setitem(
        transform_using_schema_bridge.__globals__,
        "mapping_imports",
        [{"name": "Xero", "module": mock_module}]
    )

    schema = StructType([
        StructField("Invoice Date", StringType()),
        StructField("Total$", IntegerType())
    ])

    df = spark.createDataFrame(
        [("2025-11-13", 100)],
        schema=schema
    )

    result = transform_using_schema_bridge(
        spark,
        "Xero",
        "Invoices",
        df,
        source_key="invoicedateex"
    )

    assert list(result.columns) == ["unmapped","source_system", "invoicedateex", "totalamount"]
    assert result.collect()[0]["totalamount"] == 100


def test_transform_using_schema_bridge_source_not_found(monkeypatch, spark, empty_dataframe):
    monkeypatch.setitem(
        transform_using_schema_bridge.__globals__,
        "mapping_imports",
        [{"name": "BC", "module": None}]
    )

    with pytest.raises(ValueError, match="Source system 'Xero' not found"):
        transform_using_schema_bridge(spark, "Xero", "Invoices", empty_dataframe, "name")


def test_transform_using_schema_bridge_table_not_found(monkeypatch, spark, empty_dataframe):
    mock_module = types.SimpleNamespace(objects={})

    monkeypatch.setitem(
        transform_using_schema_bridge.__globals__,
        "mapping_imports",
        [{"name": "Xero", "module": mock_module}]
    )

    with pytest.raises(ValueError, match="Table 'Invoices' not found"):
        transform_using_schema_bridge(spark, "Xero", "Invoices", empty_dataframe, "name")


# -------------------- Integration Test --------------------

def test_integration_normalization_and_transform(monkeypatch, spark):
    mock_module = types.SimpleNamespace(objects={
        "Payments": {
            "monotonically_increasing_id()": "no",
            "Amount Paid": "Amount (AUD)",
            "Date Paid": "Date Paid!"
        }
    })

    monkeypatch.setitem(
        transform_using_schema_bridge.__globals__,
        "mapping_imports",
        [{"name": "Myob", "module": mock_module}]
    )

    schema = StructType([
        StructField("Amount Paid", IntegerType()),
        StructField("Date Paid", StringType())
    ])

    df = spark.createDataFrame(
        [(500, "2025-11-13")],
        schema=schema
    )

    result =  transform_using_schema_bridge(spark, "Myob", "Payments", df, "datepaid")


    print(result.columns)

    assert list(result.columns) == ["unmapped", "source_system", 'no',"amountaud", "datepaid"]

    row = result.collect()[0].asDict()

    assert row["amountaud"] == 500
    assert row["datepaid"] == "2025-11-13"
    assert row["unmapped"] is None
