# -*- coding: utf-8 -*-
"""
SchemaBridge4BC —  A framework for merging columns from a source system into the Business Central schema
"""

__version__ = "0.0.1"

# Core subpackages
from .schemabridge import *
from .mappings import *

# Optional: explicit exports (good for linting and autocomplete)
__all__ = [
    "schemabridge",
    "mappings"
]
