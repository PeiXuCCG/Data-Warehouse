import schemabridge4bc.mappings.xero.object_mappings as  xero_mapping
import schemabridge4bc.mappings.myob.object_mappings as myob_mapping
import schemabridge4bc.mappings.netsuite.object_mappings as  netsuite_mapping
import schemabridge4bc.mappings.windward.object_mappings as  windward_mapping
import schemabridge4bc.mappings.natsoft.object_mappings as natsoft_mapping

# Transactional Systems
import schemabridge4bc.mappings.contracts.object_mappings as contracts_mapping
import schemabridge4bc.mappings.hirepos.object_mappings as hirepos_mapping
import schemabridge4bc.mappings.lightspeed.object_mappings as lightspeed_mapping
import schemabridge4bc.mappings.ostendo.object_mappings as ostendo_mapping
import schemabridge4bc.mappings.itv.object_mappings as itv_mapping

import re
from pyspark.sql.functions import expr, lit, col,monotonically_increasing_id, when
from pyspark.sql import Row
from pyspark.sql.types import MapType, StructField, StructType, StringType
# ============================================
# 1️⃣ Define your Source System → BC mappings here
# ============================================

mapping_imports = [
    {"name": "HirePos", "module": hirepos_mapping},
    {"name": "ITV", "module": itv_mapping},
    {"name": "Lightspeed", "module": lightspeed_mapping},
    {"name": "Ostendo", "module": ostendo_mapping},
    {"name": "Contracts", "module": contracts_mapping},
    {"name": "Myob", "module": myob_mapping},
    {"name": "Xero", "module": xero_mapping},
    {"name": "Netsuite", "module": netsuite_mapping},
    {"name": "Windward", "module": windward_mapping},
    {"name": "Natsoft", "module": natsoft_mapping},
]


FUNCTION_CALL_PATTERN = re.compile(
    r"^\s*[a-zA-Z_][a-zA-Z0-9_]*\s*\(",
    re.IGNORECASE
)

def normalize_column_name(name: str) -> str:
    # Lowercase, remove special characters and removing spaces
    name = name.lower()
    name = re.sub(r'[^a-z0-9]+', '', name)  # Replace non-alphanumeric 
    return name

def is_pyspark_function_call(src: str) -> bool:
    return bool(FUNCTION_CALL_PATTERN.match(src))

def transform_using_schema_bridge(spark, source_system, table_name, new_df, source_key):
    schemaToBridge = next((item for item in mapping_imports if item["name"] == source_system), None)
    if schemaToBridge is None:
        raise ValueError(f"Source system '{source_system}' not found in mapping_imports.")

    module = schemaToBridge["module"]
    table_mapping = getattr(module, "objects", {}).get(table_name)

    if table_mapping is None:
        raise ValueError(f"Table '{table_name}' not found in {source_system} mapping.")

    

    if isinstance(table_mapping, dict):
        items = table_mapping.items()
    else:
        items = table_mapping




    unmapped_fields = {}
    fields_to_select = ["unmapped", "source_system"]

    # force this to be added
    new_df =new_df.withColumn("source_system", lit(source_system))


    
    # Build normalized mappings + detect unmapped
    for src, tgt, *_ in items:

        normalized_tgt = normalize_column_name(tgt) if tgt else None

        if tgt:  # ---------- MAPPED COLUMN
            if is_pyspark_function_call(src):
                # remove the function and get to the actual fields
                args = src[src.find("(")+1 : src.rfind(")")].split(",")
                args = [a.strip() for a in args if a.strip().lower() != normalized_tgt]
                # update dataframe
                new_df = new_df.withColumn(normalized_tgt, expr(src)).drop(*args)
            elif "__EMPTY__" in src:
                new_df = new_df.withColumn(normalized_tgt, lit(None).cast(StringType()))
            elif src in new_df.columns:
                new_df = new_df.withColumnRenamed(src, normalized_tgt)
            else:
                new_df = new_df.withColumn(normalized_tgt, lit(None).cast(StringType()))

            if normalized_tgt not in fields_to_select:
                fields_to_select.append(normalized_tgt)  
        else:  # ---------- UNMAPPED COLUMN
            # Only handle unmapped IF the column exists in the dataframe
            # UNMAPPED columns will be processed later (after ID injection)
            pass


    # ----------------------------------------------------------
    # 2️⃣ NOW SAFE: apply monotonic id fill because source_key now exists
    # ----------------------------------------------------------
    if source_key in new_df.columns:
        new_df = new_df.withColumn("_mono_id", monotonically_increasing_id())
        new_df = new_df.withColumn(
            source_key,
            when(col(source_key).isNull(), col("_mono_id")).otherwise(col(source_key))
        ).drop("_mono_id")
    else:
        raise ValueError(f"source_key '{source_key}' does not exist after mapping.")
    

    # 🔥 FORCE source_key to StringType to allow for merging data sources
    new_df = new_df.withColumn(source_key, col(source_key).cast(StringType()))
    # ----------------------------------------------------------
    # 3️⃣ THIRD: process unmapped fields
    # NOW we use the *final* source_key values!
    # ----------------------------------------------------------
    for src, tgt, *_ in items:
        if tgt is not None and tgt.strip() != "":
            continue  # skip mapped columns
        
        if src in new_df.columns:
            rows = (
                new_df.select(source_key, src)
                      .where(col(src).isNotNull())
                      .collect()
            )

            for r in rows:
                row_id = r[source_key]     # <-- now correct
                value = r[src]

                if row_id not in unmapped_fields:
                    unmapped_fields[row_id] = {}

                unmapped_fields[row_id][src] = value

        else:
            unmapped_fields["missing_column_" + src] = {src: None}

    # ----------------------------------------------------------
    # 4. Continue with unmapped handling
    # ----------------------------------------------------------
    unmapped_rows = [
        Row(**{source_key: str(k), "unmapped": v})
        for k, v in unmapped_fields.items()
    ]

    if unmapped_rows:
        unmapped_df = spark.createDataFrame(unmapped_rows)
    else:
        # Explicit schema avoids "can't infer schema"
        schema = StructType([
            StructField(source_key, StringType(), True),
            StructField("unmapped", MapType(StringType(), StringType()), True)
        ])
        unmapped_df = spark.createDataFrame([], schema)


    unmapped_df = unmapped_df.withColumn("unmapped", col("unmapped"))
    new_df = new_df.join(unmapped_df, on=source_key, how="left")

    # Final select including passthrough columns
    new_df = new_df.select(fields_to_select)

    return new_df

