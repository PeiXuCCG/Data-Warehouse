import re
import os
import pkgutil
import importlib
from pyspark.sql.functions import transform_values, expr, lit, col,monotonically_increasing_id, when
from pyspark.sql import Row
from pyspark.sql.types import MapType, StructField, StructType, StringType
# ============================================
# 1️⃣ Define your Source System → BC mappings here
# ============================================

FUNCTION_CALL_PATTERN = re.compile(
    r"^\s*[a-zA-Z_][a-zA-Z0-9_]*\s*\(",
    re.IGNORECASE
)

BASE_DIR = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..")
)

PROJECT_DIR = "schemabridge4bc"

MAPPINGS_PACKAGE = f"{PROJECT_DIR}.mappings"

def normalize_source_system(name: str) -> str:
    if "pos" in name.lower():
        return name.replace("pos", "POS").replace("Pos", "POS")
    return name.capitalize()


def build_mapping_imports_from_mappings_folder():
    mapping_imports = []

    try:
        mappings_pkg = importlib.import_module(MAPPINGS_PACKAGE)
    except ModuleNotFoundError:
        raise RuntimeError(f"Mappings package not found: {MAPPINGS_PACKAGE}")

    # Iterate over subpackages under schemabridge4bc.mappings
    for module_info in pkgutil.iter_modules(mappings_pkg.__path__):
        if not module_info.ispkg:
            continue

        source_system = module_info.name
        module_path = f"{MAPPINGS_PACKAGE}.{source_system}.object_mappings"

        try:
            module = importlib.import_module(module_path)

            if not hasattr(module, "objects"):
                print(f"⚠️ {module_path} missing 'objects'")
                continue

            mapping_imports.append({
                "name": normalize_source_system(source_system),
                "module": module
            })

        except ModuleNotFoundError:
            print(f"⚠️ object_mappings.py not found for '{source_system}'")

    return mapping_imports



def normalize_column_name(name: str) -> str:
    # Lowercase, remove special characters and removing spaces
    name = name.lower()
    name = re.sub(r'[^a-z0-9]+', '', name)  # Replace non-alphanumeric 
    if name == "company":
        name = "originating_company"
    return name

def is_pyspark_function_call(src: str) -> bool:
    return bool(FUNCTION_CALL_PATTERN.match(src))

def transform_using_schema_bridge(spark, source_system, table_name, new_df, source_key):
    schemaToBridge = next((item for item in build_mapping_imports_from_mappings_folder() if item["name"].lower() == source_system.lower()), None)
    if schemaToBridge is None:
        raise ValueError(f"Source system '{source_system}' not found in mapping_imports.")

    module = schemaToBridge["module"]
    table_mapping = getattr(module, "objects", {}).get(table_name)

    if table_mapping is None:
        raise ValueError(f"Table '{table_name}' not found in {source_system} mapping.")

    

    if isinstance(table_mapping, dict):
        items = table_mapping.items()
    else:
        items = table_mapping




    unmapped_fields = {}
    fields_to_select = ["unmapped", "source_system"]

    # force this to be added
    new_df =new_df.withColumn("source_system", lit(source_system))

    #make all the columns lowercase
    new_df = new_df.select(
        *[col(c).alias(c.lower()) for c in new_df.columns]
    )

    # Build normalized mappings + detect unmapped
    for src, tgt, *_ in items:

        normalized_tgt = normalize_column_name(tgt) if tgt else None

        try:
            if tgt:  # ---------- MAPPED COLUMN
                if is_pyspark_function_call(src):
                    # remove the function and get to the actual fields
                    args = src[src.find("(")+1 : src.rfind(")")].split(",")
                    args = [a.strip() for a in args if a.strip().lower() != normalized_tgt]
                    # update dataframe
                    new_df = new_df.withColumn(normalized_tgt, expr(src)).drop(*args)
                elif "__EMPTY__" in src:
                    new_df = new_df.withColumn(normalized_tgt, lit(None).cast(StringType()))
                elif src.lower() in new_df.columns:
                    new_df = new_df.withColumnRenamed(src.lower(), normalized_tgt)
                else:
                    new_df = new_df.withColumn(normalized_tgt, lit(None).cast(StringType()))

                if normalized_tgt not in fields_to_select:
                    fields_to_select.append(normalized_tgt)  
            else:  # ---------- UNMAPPED COLUMN
                # Only handle unmapped IF the column exists in the dataframe
                # UNMAPPED columns will be processed later (after ID injection)
                pass
        except Exception as e:
            print(f"WARNING: Something went wrong with converting {src} to {normalized_tgt} - {e}")

    # ----------------------------------------------------------
    # 2️⃣ NOW SAFE: apply monotonic id fill because source_key now exists
    # ----------------------------------------------------------
    if source_key in new_df.columns:
        new_df = new_df.withColumn("_mono_id", monotonically_increasing_id())
        new_df = new_df.withColumn(
            source_key,
            when(col(source_key).isNull(), col("_mono_id")).otherwise(col(source_key))
        ).drop("_mono_id")
    else:
        raise ValueError(f"source_key '{source_key}' does not exist after mapping.")
    

    # 🔥 FORCE source_key to StringType to allow for merging data sources
    new_df = new_df.withColumn(source_key, col(source_key).cast(StringType()))
    # ----------------------------------------------------------
    # 3️⃣ THIRD: process unmapped fields
    # NOW we use the *final* source_key values!
    # ----------------------------------------------------------
    for src, tgt, *_ in items:
        try:
            # Skip mapped columns
            if tgt is not None and tgt.strip() != "":
                continue

            if src in new_df.columns:
                rows = (
                    new_df
                    .select(source_key, src)
                    .where(col(src).isNotNull())
                    .collect()
                )

                for r in rows:
                    row_id = str(r[source_key])  # enforce string key
                    value = None if r[src] is None else str(r[src])

                    if row_id not in unmapped_fields:
                        unmapped_fields[row_id] = {}

                    unmapped_fields[row_id][src] = value

            else:
                # Column missing entirely
                unmapped_fields[f"missing_column_{src}"] = {src: None}

        except Exception as e:
            print(f"WARNING: Something went wrong with unmapping of '{src}': {e}")

    # ----------------------------------------------------------
    # 2. Convert dict → Rows
    # ----------------------------------------------------------
    unmapped_rows = [
        Row(**{source_key: k, "unmapped": v})
        for k, v in unmapped_fields.items()
    ]

    # ----------------------------------------------------------
    # 3. Explicit schema (NO inference)
    # ----------------------------------------------------------
    schema = StructType([
        StructField(source_key, StringType(), True),
        StructField(
            "unmapped",
            MapType(StringType(), StringType(), True),
            True
        )
    ])

    if unmapped_rows:
        unmapped_df = spark.createDataFrame(unmapped_rows, schema)
    else:
        unmapped_df = spark.createDataFrame([], schema)

    # ----------------------------------------------------------
    # 4. Defensive cast (guarantees StringType values)
    # ----------------------------------------------------------
    unmapped_df = unmapped_df.withColumn(
        "unmapped",
        transform_values(
            col("unmapped"),
            lambda k, v: v.cast("string")
        )
    )

    # ----------------------------------------------------------
    # 5. Join back to main DataFrame
    # ----------------------------------------------------------
    new_df = new_df.join(unmapped_df, on=source_key, how="left").select(fields_to_select)

    return new_df

