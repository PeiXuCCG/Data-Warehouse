############ IMPORTANT ############
# AUTO-GENERATED FROM EXCEL
# Source: Lightspeed
###################################

import pandas as pd

objects = {
}
