############ IMPORTANT ############
# AUTO-GENERATED FROM EXCEL
# Source: Myob
###################################

import pandas as pd

objects = {
}
