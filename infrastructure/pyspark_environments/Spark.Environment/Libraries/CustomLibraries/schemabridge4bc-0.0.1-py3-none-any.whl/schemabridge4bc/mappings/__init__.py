# -*- coding: utf-8 -*-
"""
Mappings —  The source systems that can be mapped to the Business Central schema
"""



# Core subpackages
from .contracts import *
from .hirepos import *
from .itv import *
from .lightspeed import *
from .myob import *
from .natsoft import *
from .netsuite import *
from .ostendo import *
from .xero import *


# Optional: explicit exports (good for linting and autocomplete)
__all__ = [
    "contracts",
    "hirepos",
    "itv",
    "lightspeed",
    "myob",
    "natsoft",
    "netsuite",
    "ostendo",
    "windward",
    "xero"
]
