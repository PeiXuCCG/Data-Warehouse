############ IMPORTANT ############
# AUTO-GENERATED FROM EXCEL
# Source: Netsuite
###################################

import pandas as pd

objects = {
}
