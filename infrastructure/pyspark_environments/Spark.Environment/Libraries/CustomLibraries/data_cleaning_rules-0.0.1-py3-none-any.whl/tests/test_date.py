import pytest
from pyspark.sql import SparkSession, Row
from data_cleaning_rules.rule_engine import clean
from pyspark.sql.functions import expr


@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("RulesEngine").getOrCreate()


def test_date_parsing(spark):
    df = spark.createDataFrame([
        Row(date="1/7/2023"),        # D/M/Y → 01/07/2023
        Row(date="07/01/2023"),      # DD/MM/YYYY → 07/01/2023
        Row(date=None),              # Null
    ])

    expr_date = """
                date_format(
    coalesce(
        to_date(date, 'd/M/yyyy'),
        to_date(date, 'dd-MM-yyyy')   
            ),
    'dd/MM/yyyy'
    )
        """

    result = df.withColumn("cleaned", expr(expr_date)).collect()

    actual = [r.cleaned for r in result]

    expected = [
        "01/07/2023",
        "07/01/2023",
        
         None
        ]

    assert actual == expected, f"Expected {expected}, but got {actual}"