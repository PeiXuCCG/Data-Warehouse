import pytest
from pyspark.sql import SparkSession, Row
from data_cleaning_rules import clean  # <-- adjust to your package name

# -------------------------
# 🔧 Spark Session Fixture
# -------------------------
@pytest.fixture(scope="session")
def spark():
    spark = (
        SparkSession.builder
        .appName("unit-test-clean-function")
        .master("local[*]")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("ERROR")
    return spark

# -------------------------
# 🧪 TEST CASE
# -------------------------
def test_clean_function_applies_rules(spark):

    # 1️⃣ Create sample DataFrame
    sample_df = spark.createDataFrame([
        Row(stateprovince="new south wales", postalcode="2000"),
        Row(stateprovince="victoria", postalcode="3000")
    ])

    # 2️⃣ Create mock rules table DataFrame
    # → your clean() expects columns: id, source_columns, target_column, rule_set, cleaning_rule
    rules_df = spark.createDataFrame([
        Row(
            id=1,
            source_columns=["stateprovince", "postalcode"],
            target_column="stateprovince",
            rule_set="Netsuite",
            cleaning_rule="upper(stateprovince)"  # SQL rule to convert to upper case
        )
    ])

    # 3️⃣ Execute clean function
    cleaned_df = clean(sample_df, rules_df, "Netsuite")

    # 4️⃣ Convert to Python list to assert
    result = [r["stateprovince"] for r in cleaned_df.collect()]

    # 5️⃣ Expected Output
    expected = ["NEW SOUTH WALES", "VICTORIA"]

    # 6️⃣ Assertion
    assert result == expected, f"Expected {expected}, but got {result}"
