import pytest
from unittest.mock import MagicMock, patch
from pyspark.sql import Row
from pyspark.sql import SparkSession
from pyspark.sql import functions as F



@pytest.fixture(scope="session")
def spark():
    return SparkSession.builder.master("local[*]").appName("tests").getOrCreate()


@pytest.fixture
def mock_df():
    df = MagicMock()
    df.columns = ["id", "source_columns", "target_column", "rule_set", "cleaning_rule",
                  "effectivity_start_date", "effectivity_end_date", "created_by", "created_date"]
    
    df.collect.return_value = [
        {
            "id": 1,
            "source_columns": ["stateprovince", "postalcode"],
            "target_column": "stateprovince",
            "rule_set": "Netsuite",
            "cleaning_rule": "Upper(stateprovince)",
            "effectivity_start_date": None,
            "effectivity_end_date": None,
            "created_by": "tester",
            "created_date": None
        },
        {
            "id": 2,
            "source_columns": ["Not present column"],
            "target_column": "stateprovince",
            "rule_set": "Netsuite",
            "cleaning_rule": "Lower(stateprovince)",
            "effectivity_start_date": None,
            "effectivity_end_date": None,
            "created_by": "tester2",
            "created_date": None
        },
        {
            "id": 3,
            "source_columns": ["amountnet"],
            "target_column": "amountnet",
            "rule_set": "Xero",
            "cleaning_rule": "INVALID SQL EXPR",
            "effectivity_start_date": None,
            "effectivity_end_date": None,
            "created_by": "tester3",
            "created_date": None 
        },
        {
            "id": 4,
            "source_columns": ["datecolumn"],
            "target_column": "not_existing_column",
            "rule_set": "Xero",
            "cleaning_rule": "invalid_function(datecolumn)",
            "effectivity_start_date": None,
            "effectivity_end_date": None,
            "created_by": "tester4",
            "created_date": None
        },
        {
            "id": 5,
            "source_columns": ["datecolumn"],
            "target_column": "datecolumn",
            "rule_set": "not_existing_rule_set",
            "cleaning_rule": "date_add(datecolumn, 5)",
            "effectivity_start_date": None,
            "effectivity_end_date": None,
            "created_by": "tester5",
            "created_date": None
        }
        ]
    df.count.return_value = 42
    df.cache.return_value = df
    df.write = MagicMock()
    return df

def test_load_rules(spark, mock_df, caplog):
    """
    Test the load_rules function to ensure it retrieves rules correctly.
    """

    df = spark.createDataFrame([
        Row(stateprovince="nsw", postalcode="2000"),
        Row(stateprovince="vic", postalcode="3000"),
    ])



    # 1) Mock SparkSession
    mock_spark = MagicMock()
    
    # 2) Patch spark.sql() to return our mock_df
    with patch("pyspark.sql.SparkSession.getActiveSession", return_value=mock_spark):
        mock_spark.sql.return_value = mock_df
        
        # 3) Call the actual load_rules function
        from data_cleaning_rules.rule_engine import load_rules
        result = load_rules("Netsuite")   # Call original function
        
        # ---------- Assertions ----------
        assert len(result) == 5
        assert result[0]["source_columns"] == ["stateprovince", "postalcode"]
        assert result[1]["target_column"] == "stateprovince"
        assert result[0]["rule_set"] == "Netsuite"
        assert result[0]["cleaning_rule"] == "Upper(stateprovince)"
        
        mock_spark.sql.assert_called_once()
        
        assert result == mock_df.collect()