from pyspark.sql import Row, SparkSession
from data_cleaning_rules import clean
import pytest


@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("RulesEngine").getOrCreate()


def test_state_cleaning_rule():
    """
    End-to-end test ensuring rule engine applies the state cleaning rule.
    """
    # ---------------------------
    # CREATE the rules table locally for testing
    # ---------------------------
    spark.sql("""
    CREATE TABLE IF NOT EXISTS dbo.cleaning_rules_set (
        id BIGINT,
        source_columns ARRAY<STRING>,
        target_column STRING,
        rule_set STRING,
        cleaning_rule STRING,
        effectivity_start_date DATE,
        effectivity_end_date DATE,
        created_by STRING,
        created_date TIMESTAMP
    )
    USING DELTA
    """)

    # ---------------------------
    # 1) Prepare DataFrame
    # ---------------------------
    sample_df = spark.createDataFrame([
        Row(stateprovince="new south wales", postalcode="2000"),
        Row(stateprovince="VIC", postalcode="3000"),
        Row(stateprovince="Sydney", postalcode="2000"),
    ])

    # ---------------------------
    # 2) Insert fake rule
    # ---------------------------
    spark.sql("""
    INSERT INTO dbo.cleaning_rules_set
    (id, source_columns, target_column, rule_set, cleaning_rule, effectivity_start_date, created_by, created_date)
    VALUES (
        999,
        ARRAY('stateprovince','postalcode'),
        'stateprovince',
        'TEST_SET',
        'CASE WHEN upper(stateprovince) = ''NEW SOUTH WALES'' THEN ''NSW'' ELSE upper(stateprovince) END',
        current_date(),
        'unit_test',
        current_timestamp()
    )
    """)

    # ---------------------------
    # 3) Apply cleaning
    # ---------------------------
    result_df = clean(sample_df, "TEST_SET")
    results = [row["stateprovince"] for row in result_df.collect()]

    # ---------------------------
    # 4) Assert results
    # ---------------------------
    assert results[0] == "NSW"
    assert results[1] == "VIC"
    assert results[2] == "SYDNEY"

    print("🎉 TEST PASSED — State cleaning applied correctly!")

    # Cleanup (Optional)
    spark.sql("DELETE FROM dbo.cleaning_rules_set WHERE id = 999")
