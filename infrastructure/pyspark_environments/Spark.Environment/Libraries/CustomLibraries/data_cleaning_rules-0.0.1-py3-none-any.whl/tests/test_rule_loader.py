import pytest
from unittest.mock import MagicMock, patch
from pyspark.sql import SparkSession
from data_cleaning_rules.rule_loader import load_rules

def test_load_rules_mock_spark_sql():
    # 1) Mock the Spark Session
    mock_spark = MagicMock(spec=SparkSession)
    
# spark.sql("""
#     CREATE TABLE IF NOT EXISTS dbo.cleaning_rules_set (
#         id BIGINT,
#         source_columns ARRAY<STRING>,
#         target_column STRING,
#         rule_set STRING,
#         cleaning_rule STRING,
#         effectivity_start_date DATE,
#         effectivity_end_date DATE,
#         created_by STRING,
#         created_date TIMESTAMP
#     )
#     USING DELTA
#     """)   
    

@pytest.fixture
def mock_df():
    df = MagicMock()
    df.columns = ["id", "source_columns", "target_column", "rule_set", "cleaning_rule",
                  "effectivity_start_date", "effectivity_end_date", "created_by", "created_date"]
    
    df.collect.return_value = [
        {
            "id": 1,
            "source_columns": ["stateprovince", "postalcode"],
            "target_column": "stateprovince",
            "rule_set": "Netsuite",
            "cleaning_rule": "cleaning_rule_1",
            "effectivity_start_date": None,
            "effectivity_end_date": None,
            "created_by": "tester",
            "created_date": None
        }]
    df.count.return_value = 42
    df.cache.return_value = df
    df.write = MagicMock()
    return df
    
    

    # Make spark.sql() return our mock df
    mock_spark.sql.return_value = mock_df

    # 3) Patch SparkSession.getActiveSession() so it returns our mock spark
    with patch("pyspark.sql.SparkSession.getActiveSession", return_value=mock_spark):
        
        result = load_rules("Netsuite")   # Call original function
        
        # ---------- Assertions ----------
        assert len(result) == 2
        assert result[0]["source_columns"] == ["stateprovince", "postalcode"]
        assert result[1]["target_column"] == "stateprovince"
        assert result[0]["rule_set"] == "Netsuite"
        assert result[0]["cleaning_rule"] == "cleaning_rule_1"
        

        
        mock_spark.sql.assert_called_once()
        
        assert result == mock_df.collect()

