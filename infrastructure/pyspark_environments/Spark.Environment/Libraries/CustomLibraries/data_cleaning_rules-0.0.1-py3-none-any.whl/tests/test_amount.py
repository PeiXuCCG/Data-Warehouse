import pytest
from pyspark.sql import SparkSession, Row
from data_cleaning_rules.rule_engine import clean

@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("RulesEngine").getOrCreate()



# def test_clean_state_rules(spark):
#     print("Running test_clean_state_rules")
#     # 1) Create sample source dataframe
#     df = spark.createDataFrame([
#         Row(stateprovince="vic"),
#         Row(stateprovince="NSW"),
#     ])


def test_negative_amount_conversion(spark):
    sample_df = spark.createDataFrame([
        #Row(amountnet="(100)"),    # Minus and parentheses → -100
        Row(amountnet="200"),       # Should remain 200
        # Row(amountnet="(123.45)"),  # Decimal negative
        # Row(amountnet="0"),         # Zero - untouched
        # Row(amountnet=None),        # Null - remain null
    ])

    expr_sql = """
    regexp_replace(amountnet, '^\\((.*)\\)$', '-$1')  
)
"""
#     expr_sql = """
# CAST(
#     NULLIF(
#         regexp_replace(amountnet, '^\\((.*)\\)$', '-$1'),
#         ''
#     )
# AS DOUBLE)
# """
    # 2) Prepare rules as a DataFrame (matching schema for clean())
    rules_df = spark.createDataFrame([
        Row(
            id=1,
            source_columns=["amountnet"],
            target_column="amountnet",
            rule_set="Netsuite",
            cleaning_rule=expr_sql
        )
    ])

    # 3) Apply clean()
    cleaned_rows = clean(sample_df, rules_df, "Netsuite").collect()
    result = [row["amountnet"] for row in cleaned_rows]

    assert result == ["200"], f"Unexpected values: {cleaned_rows}"
