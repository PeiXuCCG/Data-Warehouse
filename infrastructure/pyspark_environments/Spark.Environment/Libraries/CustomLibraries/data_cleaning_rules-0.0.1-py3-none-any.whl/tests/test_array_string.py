import pytest
from pyspark.sql import SparkSession, Row
from data_cleaning_rules.rule_engine import clean

@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("RulesEngine").getOrCreate()


def test_clean_state_rules(spark):

    # 1) Sample input DF
    sample_df = spark.createDataFrame([
        Row(stateprovince="vic", postalcode="3000"),                # Lowercase abbreviation → VIC
        Row(stateprovince="south australia", postalcode="5000"),    # Full name → SA
        Row(stateprovince="Sydney", postalcode="2000"),             # City → NSW
        Row(stateprovince=None, postalcode="3000"),                 # Infer from postcode → VIC
    ])

    # 2) SQL rule expression
    expr_sql = """CASE
    WHEN upper(stateprovince) IN ('NSW','VIC','QLD','SA','WA','TAS','ACT','NT')
    THEN upper(stateprovince)

    WHEN stateprovince RLIKE '^[0-9]+$'
         AND (
           CASE
             WHEN (CAST(stateprovince AS INT) BETWEEN 1000 AND 2599)
               OR (CAST(stateprovince AS INT) BETWEEN 2620 AND 2899)
               OR (CAST(stateprovince AS INT) BETWEEN 2921 AND 2999) THEN 'NSW'
             WHEN (CAST(stateprovince AS INT) BETWEEN 3000 AND 3999)
               OR (CAST(stateprovince AS INT) BETWEEN 8000 AND 8999) THEN 'VIC'
             WHEN (CAST(stateprovince AS INT) BETWEEN 4000 AND 4999)
               OR (CAST(stateprovince AS INT) BETWEEN 9000 AND 9999) THEN 'QLD'
             WHEN (CAST(stateprovince AS INT) BETWEEN 5000 AND 5999) THEN 'SA'
             WHEN (CAST(stateprovince AS INT) BETWEEN 6000 AND 6999) THEN 'WA'
             WHEN (CAST(stateprovince AS INT) BETWEEN 7000 AND 7999) THEN 'TAS'
             WHEN (CAST(stateprovince AS INT) BETWEEN 200 AND 299)
               OR (CAST(stateprovince AS INT) BETWEEN 2600 AND 2619)
               OR (CAST(stateprovince AS INT) BETWEEN 2900 AND 2920) THEN 'ACT'
             WHEN (CAST(stateprovince AS INT) BETWEEN 800 AND 999) THEN 'NT'
           END
         ) IS NOT NULL
    THEN
       CASE
         WHEN (CAST(stateprovince AS INT) BETWEEN 1000 AND 2599)
           OR (CAST(stateprovince AS INT) BETWEEN 2620 AND 2899)
           OR (CAST(stateprovince AS INT) BETWEEN 2921 AND 2999) THEN 'NSW'
         WHEN (CAST(stateprovince AS INT) BETWEEN 3000 AND 3999)
           OR (CAST(stateprovince AS INT) BETWEEN 8000 AND 8999) THEN 'VIC'
         WHEN (CAST(stateprovince AS INT) BETWEEN 4000 AND 4999)
           OR (CAST(stateprovince AS INT) BETWEEN 9000 AND 9999) THEN 'QLD'
         WHEN (CAST(stateprovince AS INT) BETWEEN 5000 AND 5999) THEN 'SA'
         WHEN (CAST(stateprovince AS INT) BETWEEN 6000 AND 6999) THEN 'WA'
         WHEN (CAST(stateprovince AS INT) BETWEEN 7000 AND 7999) THEN 'TAS'
         WHEN (CAST(stateprovince AS INT) BETWEEN 200 AND 299)
           OR (CAST(stateprovince AS INT) BETWEEN 2600 AND 2619)
           OR (CAST(stateprovince AS INT) BETWEEN 2900 AND 2920) THEN 'ACT'
         WHEN (CAST(stateprovince AS INT) BETWEEN 800 AND 999) THEN 'NT'
       END

    WHEN (
           CASE
             WHEN (CAST(postalcode AS INT) BETWEEN 1000 AND 2599)
               OR (CAST(postalcode AS INT) BETWEEN 2620 AND 2899)
               OR (CAST(postalcode AS INT) BETWEEN 2921 AND 2999) THEN 'NSW'
             WHEN (CAST(postalcode AS INT) BETWEEN 3000 AND 3999)
               OR (CAST(postalcode AS INT) BETWEEN 8000 AND 8999) THEN 'VIC'
             WHEN (CAST(postalcode AS INT) BETWEEN 4000 AND 4999)
               OR (CAST(postalcode AS INT) BETWEEN 9000 AND 9999) THEN 'QLD'
             WHEN (CAST(postalcode AS INT) BETWEEN 5000 AND 5999) THEN 'SA'
             WHEN (CAST(postalcode AS INT) BETWEEN 6000 AND 6999) THEN 'WA'
             WHEN (CAST(postalcode AS INT) BETWEEN 7000 AND 7999) THEN 'TAS'
             WHEN (CAST(postalcode AS INT) BETWEEN 200 AND 299)
               OR (CAST(postalcode AS INT) BETWEEN 2600 AND 2619)
               OR (CAST(postalcode AS INT) BETWEEN 2900 AND 2920) THEN 'ACT'
             WHEN (CAST(postalcode AS INT) BETWEEN 800 AND 999) THEN 'NT'
           END
         ) IS NOT NULL
    THEN
       CASE
         WHEN (CAST(postalcode AS INT) BETWEEN 1000 AND 2599)
           OR (CAST(postalcode AS INT) BETWEEN 2620 AND 2899)
           OR (CAST(postalcode AS INT) BETWEEN 2921 AND 2999) THEN 'NSW'
         WHEN (CAST(postalcode AS INT) BETWEEN 3000 AND 3999)
           OR (CAST(postalcode AS INT) BETWEEN 8000 AND 8999) THEN 'VIC'
         WHEN (CAST(postalcode AS INT) BETWEEN 4000 AND 4999)
           OR (CAST(postalcode AS INT) BETWEEN 9000 AND 9999) THEN 'QLD'
         WHEN (CAST(postalcode AS INT) BETWEEN 5000 AND 5999) THEN 'SA'
         WHEN (CAST(postalcode AS INT) BETWEEN 6000 AND 6999) THEN 'WA'
         WHEN (CAST(postalcode AS INT) BETWEEN 7000 AND 7999) THEN 'TAS'
         WHEN (CAST(postalcode AS INT) BETWEEN 200 AND 299)
           OR (CAST(postalcode AS INT) BETWEEN 2600 AND 2619)
           OR (CAST(postalcode AS INT) BETWEEN 2900 AND 2920) THEN 'ACT'
         WHEN (CAST(postalcode AS INT) BETWEEN 800 AND 999) THEN 'NT'
       END

    WHEN upper(stateprovince) = 'NEW SOUTH WALES'            THEN 'NSW'
    WHEN upper(stateprovince) = 'VICTORIA'                   THEN 'VIC'
    WHEN upper(stateprovince) = 'QUEENSLAND'                 THEN 'QLD'
    WHEN upper(stateprovince) = 'SOUTH AUSTRALIA'            THEN 'SA'
    WHEN upper(stateprovince) = 'WESTERN AUSTRALIA'          THEN 'WA'
    WHEN upper(stateprovince) = 'TASMANIA'                   THEN 'TAS'
    WHEN upper(stateprovince) = 'NORTHERN TERRITORY'         THEN 'NT'
    WHEN upper(stateprovince) = 'AUSTRALIAN CAPITAL TERRITORY' THEN 'ACT'

    WHEN upper(stateprovince) = 'MELBOURNE' THEN 'VIC'
    WHEN upper(stateprovince) = 'SYDNEY'    THEN 'NSW'
    WHEN upper(stateprovince) = 'BRISBANE'  THEN 'QLD'
    WHEN upper(stateprovince) = 'PERTH'     THEN 'WA'
    WHEN upper(stateprovince) = 'ADELAIDE'  THEN 'SA'
    WHEN upper(stateprovince) = 'HOBART'    THEN 'TAS'
    WHEN upper(stateprovince) = 'DARWIN'    THEN 'NT'
    WHEN upper(stateprovince) = 'CANBERRA'  THEN 'ACT'

    ELSE upper(stateprovince)
END
"""

    # 3) Rule set as DataFrame
    rules_df = spark.createDataFrame([
        Row(
            id=1,
            source_columns=["stateprovince", "postalcode"],  # Test ARRAY case
            target_column="stateprovince",
            rule_set="Netsuite",
            cleaning_rule=expr_sql
        )
    ])

    # 4) Execute cleaner
    result = clean(sample_df, rules_df, "Netsuite").collect()

    # 5) Assertions
    assert result[0]["stateprovince"] == "VIC"
    assert result[1]["stateprovince"] == "SA"
    assert result[2]["stateprovince"] == "NSW"
    assert result[3]["stateprovince"] == "VIC"

    print("All assertions passed for test_clean_state_rules")
