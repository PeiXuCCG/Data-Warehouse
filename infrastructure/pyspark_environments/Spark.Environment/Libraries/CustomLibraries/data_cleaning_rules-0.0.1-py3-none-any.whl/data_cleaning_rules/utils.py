from typing import List
from pyspark.sql import DataFrame

def missing_columns(df: DataFrame, expected_cols: List[str]) -> List[str]:
    """Return missing columns that are expected but not present."""
    return [c for c in expected_cols if c not in df.columns]

def log_info(message: str):
    """Log an informational message."""
    print(f"[INFO] {message}")

def log_warning(message: str):
    """Log a warning message."""
    print(f"[WARN] {message}")

def log_error(message: str):
    """Log an error message."""
    print(f"[ERROR] {message}")
