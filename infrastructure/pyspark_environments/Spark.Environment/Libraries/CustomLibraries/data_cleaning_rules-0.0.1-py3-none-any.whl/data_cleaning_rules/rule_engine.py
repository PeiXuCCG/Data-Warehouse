from typing import Set
from pyspark.sql import DataFrame
from pyspark.sql.functions import expr
from pyspark.sql.utils import AnalysisException
from py4j.protocol import Py4JJavaError

from .utils import missing_columns, log_info, log_warning, log_error


def clean(df: DataFrame, all_rules: DataFrame, rule_set: str) -> DataFrame:
    """
    Behaviour:
    - If source_column == target_column:
        - Create <column>original (NO underscore)
        - Replace source column with cleaned values
        - Drop raw source column at the end
    - If source_column != target_column:
        - ONLY create/update target column
        - Do NOT create any original column
    """

    # =====================================================
    # 0 Load rules
    # =====================================================
    rules = all_rules.filter(f"rule_set = '{rule_set}'").collect()

    if not rules:
        log_warning(f"No rules found for rule_set '{rule_set}'.")
        return df

    df_clean = df

    # =====================================================
    # 1 Identify in-place rules (source == target)
    # =====================================================
    inplace_columns: Set[str] = set()

    for rule in rules:
        tgt_col = rule["target_column"]
        raw_src = rule["source_columns"]

        if isinstance(raw_src, list):
            src_cols = [c.strip() for c in raw_src if c]
        elif isinstance(raw_src, str):
            src_cols = [c.strip() for c in raw_src.split(",") if c.strip()]
        else:
            continue

        if tgt_col in src_cols:
            inplace_columns.add(tgt_col)

    # =====================================================
    # 2 Preserve originals ONCE (NO underscore)
    # =====================================================
    for col in inplace_columns:
        if col in df_clean.columns:
            original_col = f"{col}original"   # ✅ NO UNDERSCORE
            if original_col not in df_clean.columns:
                df_clean = df_clean.withColumn(original_col, expr(col))
                log_info(f"Preserved '{col}' as '{original_col}'")

    # =====================================================
    # 3 Apply rules
    # =====================================================
    for rule in rules:
        rule_id = rule["id"]
        tgt_col = rule["target_column"]
        sql_expr = rule["cleaning_rule"]

        raw_src = rule["source_columns"]
        if isinstance(raw_src, list):
            src_cols = [c.strip() for c in raw_src if c]
        elif isinstance(raw_src, str):
            src_cols = [c.strip() for c in raw_src.split(",") if c.strip()]
        else:
            src_cols = []

        missing = missing_columns(df_clean, src_cols)
        if missing:
            log_warning(f"Skipping Rule {rule_id} — missing {missing}")
            continue

        log_info(
             f"Applying Rule {rule_id} on '{tgt_col}' "
            f"(rule_set='{rule_set}')")
        log_info(f"Required columns: {src_cols}")

        try:
            df_clean = df_clean.withColumn(tgt_col, expr(sql_expr))
            df_clean.select(tgt_col).limit(1).count()
            log_info(
             f"Applied Rule {rule_id} on '{tgt_col}' "
             f"(rule_set='{rule_set}') successfully"
            )


        except Py4JJavaError as e:
            log_error(f"Py4JJavaError in Rule {rule_id}: {e.java_exception}")

        except AnalysisException as e:
            log_error(f"AnalysisException in Rule {rule_id}: {str(e)}")

        except Exception as e:
            log_error(f"Unexpected error in Rule {rule_id}: {str(e)}")

    # =====================================================
    # 4 Drop raw source column ONLY for in-place rules
    # =====================================================

    return df_clean
