from typing import Set, List
from pyspark.sql import DataFrame
from pyspark.sql.functions import expr
from pyspark.sql.utils import AnalysisException
from py4j.protocol import Py4JJavaError

from .utils import missing_columns, log_info, log_warning, log_error


def clean(df: DataFrame, all_rules: DataFrame, rule_set: str) -> DataFrame:
    """
    Clean a dataframe using all rules belonging to the specified rule_set.

    Behaviour:
    - Creates <source_column>_original ONCE before any rules
    - Applies ALL valid rules
    - Allows multiple rules on the same source column
    - Drops raw source columns ONLY after all rules
    """

    # =====================================================
    # 0️ Load rules
    # =====================================================
    rules = all_rules.filter(f"rule_set = '{rule_set}'").collect()

    if not rules:
        log_warning(f"No rules found for rule_set '{rule_set}'. Nothing to clean.")
        return df

    df_clean = df

    # =====================================================
    # 1️ Collect ALL source & target columns
    # =====================================================
    all_source_cols: Set[str] = set()
    all_target_cols: Set[str] = set()

    for rule in rules:
        raw_src = rule["source_columns"]

        if isinstance(raw_src, list):
            src_cols = [c.strip() for c in raw_src if c]
        elif isinstance(raw_src, str):
            src_cols = [c.strip() for c in raw_src.split(",") if c.strip()]
        else:
            src_cols = []

        all_source_cols.update(src_cols)
        all_target_cols.add(rule["target_column"])

    # =====================================================
    # 2️ Preserve original source columns (ONCE)
    # =====================================================
    missing_for_preserve = missing_columns(df_clean, list(all_source_cols))
    if missing_for_preserve:
        log_warning(
            f"Missing source columns for preservation: {missing_for_preserve}"
        )

    for src in all_source_cols:
        if src in df_clean.columns:
            original_col = f"{src}_original"
            if original_col not in df_clean.columns:
                df_clean = df_clean.withColumn(original_col, expr(src))

    # =====================================================
    # 3️ Apply ALL rules (NO DROPS HERE)
    # =====================================================
    for rule in rules:
        rule_id = rule["id"]
        tgt_col: str = rule["target_column"]
        sql_expr: str = rule["cleaning_rule"]

        raw_src = rule["source_columns"]
        if isinstance(raw_src, list):
            src_cols = [c.strip() for c in raw_src if c]
        elif isinstance(raw_src, str):
            src_cols = [c.strip() for c in raw_src.split(",") if c.strip()]
        else:
            src_cols = []

        log_info(
            f"Applying Rule {rule_id} on '{tgt_col}' (rule_set='{rule_set}')"
        )
        log_info(f"Required columns: {src_cols}")

        #  HARD GUARD — skip rule if source columns missing
        missing = missing_columns(df_clean, src_cols)
        if missing:
            log_warning(
                f"Skipping Rule {rule_id} — missing source columns: {missing}"
            )
            continue

        try:
            df_clean = df_clean.withColumn(tgt_col, expr(sql_expr))
            log_info(f"Applied Rule {rule_id} successfully")

        except Py4JJavaError as e:
            log_error(f"Py4JJavaError in Rule {rule_id}: {str(e)}")

        except AnalysisException as e:
            log_error(f"AnalysisException in Rule {rule_id}: {str(e)}")

        except Exception as e:
            log_error(f"Unexpected error in Rule {rule_id}: {str(e)}")

    # =====================================================
    # 4️ Drop raw source columns AFTER all rules
    #    (only if NOT also a target)
    # =====================================================
    for src in all_source_cols:
        if src not in all_target_cols and src in df_clean.columns:
            df_clean = df_clean.drop(src)

    return df_clean
