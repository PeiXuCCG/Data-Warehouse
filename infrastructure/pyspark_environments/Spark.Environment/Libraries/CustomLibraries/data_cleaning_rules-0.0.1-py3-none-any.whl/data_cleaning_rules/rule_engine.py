from typing import List
from pyspark.sql import DataFrame
from pyspark.sql.functions import expr
from pyspark.sql.utils import AnalysisException


from .rule_loader import load_rules
from .utils import missing_columns, log_info, log_warning, log_error



def clean(df: DataFrame, all_rules: DataFrame, rule_set: str) -> DataFrame:
    """
    Clean a dataframe using all rules belonging to the specified rule_set.
    
    Parameters:
        df       : The input Spark DataFrame to be cleaned
        rule_set : Rule set name e.g., 'Netsuite', 'Xero', 'BC'
    
    Returns:
        DataFrame : Cleaned dataframe
    """

    rules = all_rules.filter(f"rule_set = '{rule_set}'").collect()

    if not rules:
        log_warning(f"No rules found for rule_set '{rule_set}'. Nothing to clean.")
        return df

    df_clean = df

    for rule in rules:
        rule_id = rule["id"]
        #src_cols: List[str] = rule["source_columns"]

        raw_src = rule["source_columns"]

        # 🔥 FIXED: support both LIST and STRING
        if isinstance(raw_src, list):
            src_cols = [c.strip() for c in raw_src if c]
        elif isinstance(raw_src, str):
            src_cols = [c.strip() for c in raw_src.split(",") if c.strip()]
        else:
            src_cols = []

        tgt_col: str = rule["target_column"]
        sql_expr: str = rule["cleaning_rule"]

        log_info(f"Applying Rule {rule_id} on '{tgt_col}' (rule_set='{rule_set}')")
        log_info(f"Required columns: {src_cols}")

        # Validate source columns
        missing = missing_columns(df_clean, src_cols)
        if missing:
            log_warning(f"Skipping Rule {rule_id} — missing columns: {missing}")
            continue

        # Apply rule
        try:
            df_clean = df_clean.withColumn(tgt_col, expr(sql_expr))
            log_info(f"Applied Rule {rule_id} successfully")

        except AnalysisException as e:
            log_error(f"AnalysisException in Rule {rule_id}: {str(e)}")

        except Exception as e:
            log_error(f"Unexpected error in Rule {rule_id}: {str(e)}")

    return df_clean
