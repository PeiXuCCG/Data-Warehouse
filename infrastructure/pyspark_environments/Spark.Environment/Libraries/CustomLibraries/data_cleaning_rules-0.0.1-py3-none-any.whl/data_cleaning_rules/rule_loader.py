from pyspark.sql import SparkSession

TABLE_NAME = "dbo.cleaning_rules_set"

def load_rules(rule_set: str, table_name: str = TABLE_NAME):
    """
    Load all active cleaning rules for the given rule_set.
    A rule is active when its effectivity dates align.
    """
    spark = SparkSession.getActiveSession()
    if spark is None:
        raise Exception("No active Spark session found.")

    df = spark.sql(f"""
        SELECT *
        FROM {table_name}
        WHERE rule_set = '{rule_set}'
          AND (effectivity_start_date IS NULL OR effectivity_start_date <= current_date())
          AND (effectivity_end_date IS NULL OR effectivity_end_date >= current_date())
        ORDER BY id
    """)

    return df.collect()
