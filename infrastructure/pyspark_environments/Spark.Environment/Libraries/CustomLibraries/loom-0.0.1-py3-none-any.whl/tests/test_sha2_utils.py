import pytest
from pyspark.sql import SparkSession, functions as F
from loom.utils.hashing import compute_sha2_256, sha2_const  # adjust path to match your project

@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("sha2_test").getOrCreate()


def test_compute_sha2_256_hashes_multiple_columns(spark):
    # Input DataFrame
    df = spark.createDataFrame(
        [("A", "1"), ("B", "2"), ("C", "3")],
        ["col1", "col2"]
    )

    # Apply hash function
    result_df = compute_sha2_256(df, ["col1", "col2"], "hash_val")

    # Ensure new column added
    assert "hash_val" in result_df.columns

    # Compute expected hash manually
    expected_hash = (
        spark.range(1)
        .select(F.sha2(F.concat_ws("|", F.lit("A"), F.lit("1")), 256).alias("hash"))
        .collect()[0]["hash"]
    )

    # Validate first row's hash
    first_row = result_df.collect()[0]
    assert first_row["hash_val"] == expected_hash


def test_sha2_const_hashes_constant_value(spark):
    # Input DataFrame (single row)
    df = spark.createDataFrame([("dummy",)], ["col1"])

    # Apply constant hash
    result_df = sha2_const(df, "const_hash", "-1")

    # Ensure new column added
    assert "const_hash" in result_df.columns

    # Compute expected hash of "-1"
    expected_hash = (
        spark.range(1)
        .select(F.sha2(F.concat_ws("|", F.lit("-1")), 256).alias("hash"))
        .collect()[0]["hash"]
    )

    # Validate that the hash matches
    row = result_df.collect()[0]
    assert row["const_hash"] == expected_hash


def test_compute_sha2_256_empty_column_list_raises(spark):
    df = spark.createDataFrame([("x",)], ["col1"])
    # Should fail if no columns provided
    with pytest.raises(Exception):
        compute_sha2_256(df, [], "hash_val")
