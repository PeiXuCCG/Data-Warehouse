import pytest
from pyspark.sql import SparkSession, functions as F
from functools import reduce
from pyspark.sql.types import *
from loom.tables.master_linked_table import MasterLinkedTable


# --------------------------------------------------
# Spark fixture
# --------------------------------------------------
@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("test").getOrCreate()


# --------------------------------------------------
# prepare() tests (unchanged)
# --------------------------------------------------
def test_prepare_joins_with_matching_keys(monkeypatch: pytest.MonkeyPatch, spark):
    def mock_add_ingestion_metadata(df, *_):
        return df.withColumn("ingestion_timestamp", F.lit("2025-01-01"))

    monkeypatch.setattr(
        "loom.tables.master_linked_table.add_ingestion_metadata",
        mock_add_ingestion_metadata,
    )

    df = spark.createDataFrame(
        [("A1", "prod_hk_1", "P1", "C1", "cust_fk")],
        ["SalesID", "product_hk", "productcode", "customerid", "customer_fk"],
    )

    product_master_df = spark.createDataFrame(
        [("prod_master_key", "P1", "prod_hk_1", "Product")],
        ["product_master_hk", "productcode", "product_hk", "productname"],
    )

    master_links = [
        ("product_master_hk", product_master_df, "product_hk", ["productname"])
    ]

    table = MasterLinkedTable(
        target_schema="dbo",
        target_db="public",
        name="sales",
        df=df,
        existing_df=df,
        schema_evolution=False,
        target_path="/tmp/public",
        transform=None,
        business_keys=["SalesID"],
        primary_key=["sales_hk"],
        master_links=master_links,
    )

    result_df = table.prepare()
    rec = result_df.collect()[0].asDict()

    assert rec["product_master_hk"] == "prod_master_key"
    assert "productname" in result_df.columns
    assert "ingestion_timestamp" in result_df.columns


def test_prepare_replaces_missing_keys_with_sha(monkeypatch: pytest.MonkeyPatch, spark):
    def mock_add_ingestion_metadata(df, *_):
        return df.withColumn("ingestion_timestamp", F.lit("2025-01-01"))

    monkeypatch.setattr(
        "loom.tables.master_linked_table.add_ingestion_metadata",
        mock_add_ingestion_metadata,
    )

    df = spark.createDataFrame(
        [("A2", "product_hk", "P2", "C99", "cust_hk_1")],
        ["SalesID", "product_hk", "productcode", "customerid", "customer_fk"],
    )

    product_master_df = spark.createDataFrame(
        [("prod_master_key", "P1", "prod_hk_1", "Product")],
        ["product_master_hk", "productcode", "product_hk", "productname"],
    )

    master_links = [
        ("product_master_hk", product_master_df, "product_hk", ["productname"])
    ]

    table = MasterLinkedTable(
        target_schema="dbo",
        target_db="public",
        name="sales",
        df=df,
        existing_df=df,
        schema_evolution=False,
        target_path="/tmp/public",
        transform=None,
        business_keys=["SalesID"],
        primary_key=["sales_hk"],
        master_links=master_links,
    )

    result_df = table.prepare()
    rec = result_df.collect()[0].asDict()

    sha_minus1 = (
        spark.range(1)
        .select(F.sha2(F.lit("-1"), 256).alias("hash"))
        .collect()[0]["hash"]
    )

    assert rec["product_master_hk"] == sha_minus1
    assert rec["productname"] is None
    assert "ingestion_timestamp" in result_df.columns


# --------------------------------------------------
# apply_scd_type2 — WAREHOUSE MODE
# --------------------------------------------------
def test_apply_scd_type2_warehouse(spark):
    existing_schema = StructType([
        StructField("id", IntegerType()),
        StructField("name", StringType()),
        StructField("city", StringType()),
        StructField("effectivity_start_date", TimestampType()),
        StructField("effectivity_end_date", TimestampType()),
        StructField("ingestion_timestamp", TimestampType()),
    ])

    existing_df = spark.createDataFrame(
    [
        (1, "Alice", "NY", None, None, None),
        (2, "Bob", "SF", None, None, None),
    ],
    schema=existing_schema
)

    incoming_schema = StructType([
        StructField("id", IntegerType()),
        StructField("name", StringType()),
        StructField("city", StringType()),
    ])

    incoming_df = spark.createDataFrame(
        [
            (1, "Alice", "NY"),
            (2, "Bob", "LA"),
            (3, "Carol", "LA"),
        ],
        schema=incoming_schema
    )

    table = MasterLinkedTable(
        target_schema="dbo",
        target_db="public",
        name="customer",
        df=incoming_df,
        existing_df=existing_df,
        schema_evolution=False,
        target_path="/tmp/public",
        transform=None,
        business_keys=["id"],
        primary_key=["id"],
        master_links=[("id",)],
    )

    table.is_warehouse = True
    result_df = table.apply_scd_type2(incoming_df)
    result = result_df.collect()
    assert len(result) == 4



def test_apply_scd_type2_warehouse_empty_existing(spark):
    empty_existing_df = spark.createDataFrame(
        [],
        StructType([
            StructField("id", IntegerType()),
            StructField("name", StringType()),
            StructField("city", StringType()),
            StructField("effectivity_end_date", TimestampType()),
        ]),
    )

    incoming_df = spark.createDataFrame(
        [(1, "Alice", "NY")],
        ["id", "name", "city"],
    )

    table = MasterLinkedTable(
        target_schema="dbo",
        target_db="public",
        name="customer",
        df=incoming_df,
        existing_df=empty_existing_df,
        schema_evolution=False,
        target_path="/tmp/public",
        transform=None,
        business_keys=["id"],
        primary_key=["id"],
        master_links=[("id",)],
    )

    table.is_warehouse = True

    result = table.apply_scd_type2(incoming_df).collect()

    assert len(result) == 1
    assert result[0].id == 1
