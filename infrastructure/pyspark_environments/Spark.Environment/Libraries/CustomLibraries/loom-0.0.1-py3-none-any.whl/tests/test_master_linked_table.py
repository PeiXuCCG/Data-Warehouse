import pytest
from pyspark.sql import SparkSession, Row, functions as F
from loom.tables.master_linked_table import MasterLinkedTable

@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("test").getOrCreate()

def test_prepare_joins_with_matching_keys(monkeypatch: pytest.MonkeyPatch, spark):
    # --- Mock metadata function ---
    def mock_add_ingestion_metadata(df, *_):
        return df.withColumn("ingestion_timestamp", F.lit("2025-01-01"))
    monkeypatch.setattr(
        "loom.tables.master_linked_table.add_ingestion_metadata",
        mock_add_ingestion_metadata
    )

    # --- Base dataframe (only matching keys) ---
    df = spark.createDataFrame(
        [("A1", "P1", "C1")],
        ["SalesID", "productcode", "customerid"]
    )

    # --- Master dataframes ---
    product_master_df = spark.createDataFrame(
        [("P1", "prod_hk_1", "Product")],
        ["productcode", "product_hk", "name"]
    )

    customer_master_df = spark.createDataFrame(
        [("C1", "cust_hk_1", "Fred")],
        ["customerid", "customer_hk", "name"]
    )

    # --- Master link configs ---
    master_links = [
        ("product_master_hk", product_master_df, "productcode", "product_hk", [{"ProductName": "name"}]),
        ("customer_master_hk", customer_master_df, "customerid", "customer_hk", [{"CustomerName": "name"}]),
    ]

    # --- Create and prepare ---
    table = MasterLinkedTable(
        target_schema="dbo",
        target_db="public",
        name="sales",
        df=df,
        schema_evolution=False,
        target_path="/tmp/public",
        transform=None,
        business_keys=["SalesID"],
        primary_key=["sales_hk"],
        master_links=master_links,
    )
    result_df = table.prepare()
    rec = result_df.collect()[0].asDict()

    # --- Assertions ---
    assert rec["product_master_hk"] == "prod_hk_1"
    assert rec["customer_master_hk"] == "cust_hk_1"
    assert "ingestion_timestamp" in result_df.columns


def test_prepare_replaces_missing_keys_with_sha(monkeypatch: pytest.MonkeyPatch, spark):
    # --- Mock metadata ---
    def mock_add_ingestion_metadata(df, *_):
        return df.withColumn("ingestion_timestamp", F.lit("2025-01-01"))
    monkeypatch.setattr(
        "loom.tables.master_linked_table.add_ingestion_metadata",
        mock_add_ingestion_metadata
    )

    # --- Base dataframe with missing keys ---
    df = spark.createDataFrame(
        [("A2", "P2", "C99")],
        ["SalesID", "productcode", "customerid"]
    )

    # --- Master dataframes ---
    product_master_df = spark.createDataFrame(
        [("P1", "prod_hk_1", "Product")],
        ["productcode", "product_hk", "name"]
    )

    customer_master_df = spark.createDataFrame(
        [("C1", "cust_hk_1", "Fred")],
        ["customerid", "customer_hk", "name"]
    )

    master_links = [
        ("product_master_hk", product_master_df, "productcode", "product_hk", [{"ProductName": "name"}]),
        ("customer_master_hk", customer_master_df, "customerid", "customer_hk", [{"CustomerName": "name"}]),
    ]

    table = MasterLinkedTable(
        target_schema="dbo",
        target_db="public",
        name="sales",
        df=df,
        schema_evolution=False,
        target_path="/tmp/public",
        transform=None,
        business_keys=["SalesID"],
        primary_key=["sales_hk"],
        master_links=master_links,
    )
    result_df = table.prepare()
    rec = result_df.collect()[0].asDict()

    # --- Expected SHA2('-1', 256) ---
    sha_minus1 = spark.range(1).select(F.sha2(F.lit("-1"), 256).alias("hash")).collect()[0]["hash"]

    # --- Assertions ---
    assert rec["product_master_hk"] == sha_minus1
    assert rec["customer_master_hk"] == sha_minus1
    assert "ingestion_timestamp" in result_df.columns
