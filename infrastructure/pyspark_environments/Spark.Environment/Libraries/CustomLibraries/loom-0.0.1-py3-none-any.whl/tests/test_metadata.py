import pytest
from pyspark.sql import SparkSession
from pyspark.sql.types import TimestampType
from loom.utils.metadata import add_ingestion_metadata


@pytest.fixture(scope="module")
def spark():
    """Create a single Spark session for all tests."""
    return SparkSession.builder \
        .appName("test-add-ingestion-metadata") \
        .master("local[*]") \
        .getOrCreate()


def test_add_ingestion_metadata_without_effectivity(spark):
    # Arrange
    df = spark.createDataFrame(
        [(1, "Alice"), (2, "Bob")],
        ["id", "name"]
    )

    # Act
    result = add_ingestion_metadata(df, add_effectivity=False)

    # Assert
    assert "ingestion_timestamp" in result.columns
    assert "effectivity_start_date" not in result.columns
    assert "effectivity_end_date" not in result.columns

    # Validate type
    field = next(f for f in result.schema.fields if f.name == "ingestion_timestamp")
    assert isinstance(field.dataType, TimestampType)


def test_add_ingestion_metadata_with_effectivity(spark):
    # Arrange
    df = spark.createDataFrame(
        [(1, "Alice")],
        ["id", "name"]
    )

    # Act
    result = add_ingestion_metadata(df, add_effectivity=True)

    # Assert
    for col in ["ingestion_timestamp", "effectivity_start_date", "effectivity_end_date"]:
        assert col in result.columns

    # Validate data types
    for col in ["ingestion_timestamp", "effectivity_start_date", "effectivity_end_date"]:
        field = next(f for f in result.schema.fields if f.name == col)
        assert isinstance(field.dataType, TimestampType)

    # effectivity_end_date should be null
    row = result.select("effectivity_end_date").collect()[0]
    assert row["effectivity_end_date"] is None
