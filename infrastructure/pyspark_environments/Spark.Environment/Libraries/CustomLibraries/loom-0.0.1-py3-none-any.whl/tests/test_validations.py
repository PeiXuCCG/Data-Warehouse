import pytest
from pyspark.sql import SparkSession
from loom.utils.validation import assert_no_duplicate_active_records, DuplicateRecordsError
from pyspark.sql.types import IntegerType, StringType, DateType, StructField, StructType

@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder \
        .appName("test-assert-no-duplicates") \
        .master("local[*]") \
        .getOrCreate()



def test_no_duplicates_passes(spark):
    df = spark.createDataFrame(
        [(1, "Alice", "2024-05-09"), (2, "Bob", '2024-06-10')],
        ["id", "name", "effectivity_end_date"]
    )

    # Should not raise
    assert_no_duplicate_active_records(df, "effectivity_end_date")


def test_no_duplicates_subset_passes(spark):
    df = spark.createDataFrame(
        [(1, "Alice", '2024-09-04'), (1, "Bob", None)],  # duplicate id but different name
        ["id", "name", "effectivity_end_date"]
    )

    # Should not raise since we check only the name column
    assert_no_duplicate_active_records(df,scd2field="effectivity_end_date", subset=["name"])


def test_duplicates_raise_default_all_columns(spark):

    dataframe_schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("effectivity_end_date", DateType(), True)   # Spark LongType == pandas int64
    ])

    df = spark.createDataFrame(
        [(1, "Alice", None), (1, "Alice", None)],
     schema=dataframe_schema)

    with pytest.raises(DuplicateRecordsError, match="Duplicate records detected"):
        assert_no_duplicate_active_records(df, "effectivity_end_date")


def test_duplicates_raise_subset(spark):

    dataframe_schema = StructType([
        StructField("id", IntegerType(), True),
        StructField("name", StringType(), True),
        StructField("effectivity_end_date", DateType(), True)   # Spark LongType == pandas int64
    ])

    df = spark.createDataFrame(
        [(1, "Alice", None), (1, "Bob", None)],  # duplicate id
     schema=dataframe_schema)

    with pytest.raises(DuplicateRecordsError):
        assert_no_duplicate_active_records(df, scd2field="effectivity_end_date", subset=["id"])
