import pytest
from pyspark.sql import SparkSession
from loom.utils.validation import assert_no_duplicates, DuplicateRecordsError


@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder \
        .appName("test-assert-no-duplicates") \
        .master("local[*]") \
        .getOrCreate()


def test_no_duplicates_passes(spark):
    df = spark.createDataFrame(
        [(1, "Alice"), (2, "Bob")],
        ["id", "name"]
    )

    # Should not raise
    assert_no_duplicates(df)


def test_no_duplicates_subset_passes(spark):
    df = spark.createDataFrame(
        [(1, "Alice"), (1, "Bob")],  # duplicate id but different name
        ["id", "name"]
    )

    # Should not raise since we check only the name column
    assert_no_duplicates(df, subset=["name"])


def test_duplicates_raise_default_all_columns(spark):
    df = spark.createDataFrame(
        [(1, "Alice"), (1, "Alice")],
        ["id", "name"]
    )

    with pytest.raises(DuplicateRecordsError, match="Duplicate records detected"):
        assert_no_duplicates(df)


def test_duplicates_raise_subset(spark):
    df = spark.createDataFrame(
        [(1, "Alice"), (1, "Bob")],  # duplicate id
        ["id", "name"]
    )

    with pytest.raises(DuplicateRecordsError):
        assert_no_duplicates(df, subset=["id"])
