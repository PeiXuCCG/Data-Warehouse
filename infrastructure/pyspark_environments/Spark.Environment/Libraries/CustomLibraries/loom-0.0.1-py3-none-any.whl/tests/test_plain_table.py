import pytest
from unittest.mock import MagicMock, patch
from loom.tables.plain_table import PlainTable


@pytest.fixture
def mock_df():
    """Create a mock Spark DataFrame with expected behavior."""
    df = MagicMock(name="mockDataFrame")

    # Pretend DF has two columns
    df.columns = ["id", "name"]

    # Chainable withColumn
    df.withColumn.return_value = df

    return df


@patch("loom.tables.plain_table.add_ingestion_metadata")
@patch("loom.tables.plain_table.add_source_metadata")
def test_prepare_adds_metadata_and_source_fields(
    mock_add_source_metadata,
    mock_add_ingestion_metadata,
    mock_df
):
    """
    Ensure prepare() calls metadata functions and adds columns.
    """

    # --- FIX: ensure patched functions return the SAME df and run withColumn ---
    def fake_add_source_metadata(df, system):
        df.withColumn("source_system", system)
        return df

    def fake_add_ingestion_metadata(df, flag):
        df.withColumn("ingestion_timestamp", "now")
        return df

    mock_add_source_metadata.side_effect = fake_add_source_metadata
    mock_add_ingestion_metadata.side_effect = fake_add_ingestion_metadata
    # --------------------------------------------------------------------------

    table = PlainTable(
        target_schema="dbo",
        target_db="public",
        name="customers_raw",
        source_system="SystemX",
        df=mock_df,
        target_path="/tmp/public/customers_raw",
        write_method="overwrite",
        schema_evolution=False,
        cleanse_function=None,
    )

    # Act
    result_df = table.prepare()

    # Validate returned DF is same object
    assert result_df is mock_df

    # metadata functions called properly
    mock_add_source_metadata.assert_called_once_with(mock_df, "SystemX")
    mock_add_ingestion_metadata.assert_called_once_with(mock_df, False)

    # Validate withColumn calls
    added_columns = {call.args[0] for call in mock_df.withColumn.call_args_list}

    assert {
        "source_system",
        "ingestion_timestamp",
    }.issubset(added_columns)


def test_prepare_raises_if_no_columns():
    """Prepare should raise when dataframe has no schema."""
    mock_df = MagicMock()
    mock_df.columns = []

    table = PlainTable(
        target_schema="dbo",
        target_db="public",
        name="empty_table",
        source_system="Sys",
        df=mock_df,
        target_path="/tmp/public/empty",
        write_method="append",
        schema_evolution=True,
        cleanse_function=None,
    )

    with pytest.raises(ValueError, match="has no columns defined"):
        table.prepare()
