import pytest
from unittest.mock import MagicMock, patch
from pyspark.sql import SparkSession
from loom.pipelines.pipeline import Pipeline
from loom.tables.table_type import TableType
from loom.tables.base_table import BaseTable


# -------------------------------
# Dummy subclass for BaseTable
# -------------------------------
class DummyTable(BaseTable):
    def prepare(self):
        self.df = self.df.withColumn("prepared_flag", self.df["id"])
        return self.df

    def set_tbl_properties(self):
        pass

    def get_partition_keys(self):
        return []
    
    def write_ingestion_log(self):
        pass

    def apply_scd_type2(self):
        pass

@pytest.fixture(scope="module")
def spark():
    """Create a Spark session for tests."""
    return SparkSession.builder.master("local[1]").appName("PipelineTests").getOrCreate()


@pytest.fixture
def dummy_df(spark):
    """Sample DataFrame for tests."""
    return spark.createDataFrame([(1, "Alice"), (2, "Bob")], ["id", "name"])


@pytest.fixture
def table(tmp_path, dummy_df):
    """Create a dummy BaseTable instance."""
    return DummyTable(
        name="people",
        table_type=TableType.PLAIN,
        df=dummy_df,
        target_schema="dbo",
        target_db="db1",
        target_path=str(tmp_path)
    )


# -------------------------------
# VALIDATE TESTS
# -------------------------------

def test_validate_calls_schema_and_prepare(table):
    table.validate_schema = MagicMock()
    table.prepare = MagicMock()

    pipeline = Pipeline(name="test_pipeline", tables=[table])
    result = pipeline.validate()

    table.validate_schema.assert_called_once()
    table.prepare.assert_called_once()
    assert result is True
    assert pipeline._validated is True


def test_validate_raises_on_failure(table):
    table.validate_schema = MagicMock(side_effect=ValueError("Invalid schema"))
    pipeline = Pipeline(name="bad_pipeline", tables=[table])

    with pytest.raises(ValueError, match="Invalid schema"):
        pipeline.validate()


# -------------------------------
# EXECUTE TESTS
# -------------------------------

def test_execute_dry_run_adds_batch_id(table):
    """Dry-run should not call write(), but adds batch_id column."""
    table.write = MagicMock()
    table.preview = MagicMock()
    pipeline = Pipeline(name="dry_pipeline", tables=[table], dry_run=True)

    pipeline.validate()
    pipeline.execute()

    assert "batch_id" in table.df.columns
    table.write.assert_not_called()
    table.preview.assert_called_once()


def test_execute_raises_without_target_path(spark, dummy_df):
    """Should raise ValueError when no target_path defined and dry_run=False."""
    t = DummyTable(
        name="no_path",
        table_type=TableType.PLAIN,
        df=dummy_df,
        target_schema="dbo",
        target_db="db1",
        target_path=None
    )
    t.write = MagicMock()
    pipeline = Pipeline(name="err_pipeline", tables=[t], dry_run=False)
    pipeline._validated = True  # bypass validation

    with pytest.raises(ValueError, match="no target_path defined"):
        pipeline.execute()


def test_execute_calls_write_when_valid(table):
    """Full execution calls write() and audit log."""
    table.write = MagicMock()
    table.count = MagicMock(return_value=10)

    pipeline = Pipeline(name="prod_pipeline", tables=[table], dry_run=False)
    pipeline.validate()

  
    pipeline.execute()

    table.write.assert_called_once()
    



       
# -------------------------------
# UTILITY TESTS
# -------------------------------

def test_summary_and_get_table(capsys, table):
    """Test summary printing and table lookup."""
    pipeline = Pipeline(name="sum_pipeline", tables=[table])
    pipeline.summary()
    output = capsys.readouterr().out
    assert "Pipeline Summary" in output
    assert pipeline.get_table("people") == table
    assert pipeline.get_table("nonexistent") is None
