from pyspark.sql import DataFrame, functions as F


class DuplicateRecordsError(Exception):
    """Custom exception raised when duplicate records are found."""
    pass


def assert_no_duplicates(df: DataFrame, subset: list[str] | None = None) -> None:
    """
    Validates that a DataFrame contains no duplicate rows.

    Args:
        df (DataFrame): The input Spark DataFrame to validate.
        subset (list[str] | None): List of column names to check for duplicates.
                                   If None, all columns are used.

    Raises:
        DuplicateRecordsError: If duplicate rows are detected.

    Example:
        >>> assert_no_duplicates(df, subset=["CustomerID"])
        # Raises DuplicateRecordsError if any CustomerID repeats
    """
    if subset is None:
        subset = df.columns

    # Count duplicate groups
    duplicate_count = (
        df.groupBy(subset)
          .count()
          .filter(F.col("count") > 1)
          .count()
    )

    if duplicate_count > 0:
        raise DuplicateRecordsError(
            f"Duplicate records detected in DataFrame for columns: {subset}. "
            f"Found {duplicate_count} duplicate group(s)."
        )
