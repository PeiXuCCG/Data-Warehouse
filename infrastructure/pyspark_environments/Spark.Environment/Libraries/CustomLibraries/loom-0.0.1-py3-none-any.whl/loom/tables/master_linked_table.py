from typing import List, Tuple
from pyspark.sql import DataFrame
from .base_table import BaseTable
from .table_type import TableType
from loom.utils.metadata import add_ingestion_metadata
from typing import Callable

import pyspark.sql.functions as F

class MasterLinkedTable(BaseTable):
    """
    MasterLinkedTable extends KeyedTable to support linking one dataset to multiple
    master datasets (e.g. Product Master, Customer Master, etc.).

    Each master link is a tuple of:
        (alias, master_df, business_key, primary_key_col)

    Example:
        sales_table = MasterLinkedTable(
            name="sales_order_line",
            df=sales_df,
            business_keys=["salesorderlineid"],
            primary_keys=["salesorderlineid","lineno"],
            master_links=[
                ("product_master_hk", product_master_df, "productcode", "proudct_source_hk", [{"field": "field2"}])
            ]
            is_warehouse=True
        )
    """

    def __init__(
        self,
        name: str,
        df: DataFrame,
        schema_evolution: bool,
        target_path: str,
        target_db: str = None,
        target_schema: str = None,
        transform: Callable = None,
        business_keys: List[str] = [],
        primary_key: str = None,
        master_links: List[Tuple[str, DataFrame, str, str]] = [],
        is_warehouse: bool = False
    ):
        super().__init__(name, TableType.MASTERLINKED, df, schema_evolution,  target_path=target_path, target_schema=target_schema, target_db=target_db, is_warehouse=is_warehouse)
        self.master_links = master_links
        self.transform = transform
        self.primary_key = primary_key
        self.business_keys = business_keys


    def prepare(self) -> DataFrame:
        """
        Prepare the table for ingestion:
        - Join all master mappings
        - Replace missing master keys with sha2('-1', 256)
        - Add metadata fields for audit and effectivity tracking
        """
        df = self.df

        for master_alias, master_df, business_key, primary_key_col, materialized_fields in self.master_links:
            # 1️⃣ Prepare lookup dataframe (only needed cols)
            lookup_cols = [business_key, primary_key_col] + [list(f.values())[0] for f in materialized_fields]
            lookup_df = master_df.select(*lookup_cols)

            # 2️⃣ Build rename mapping for descriptive fields
            rename_map = {}
            for mapping in materialized_fields:
                for target_field, source_field in mapping.items():
                    rename_map[source_field] = target_field  # e.g. "name" -> "ProductName"

            # 3️⃣ Rename descriptive columns
            for src_col, tgt_col in rename_map.items():
                lookup_df = lookup_df.withColumnRenamed(src_col, tgt_col)

            # 4️⃣ Join master table to base df
            df = df.join(lookup_df, on=business_key, how="left")

            # 5️⃣ Materialize master key (e.g. product_master_hk = product_hk)
            df = df.withColumn(master_alias, F.col(primary_key_col))

            # 6️⃣ Replace missing master keys with sha2('-1', 256)
            df = df.withColumn(
                master_alias,
                F.when(F.col(master_alias).isNotNull(), F.col(master_alias))
                .otherwise(F.sha2(F.lit("-1"), 256))
            )

            # 7️⃣ Only materialize/update lookup fields if the master key exists
            for mapping in materialized_fields:
                for target_field, _ in mapping.items():
                    df = df.withColumn(
                        target_field,
                        F.when(F.col(master_alias) != F.sha2(F.lit("-1"), 256), F.col(target_field))
                        .otherwise(F.col(target_field))  # keep original if missing
                    )

        # 8️⃣ Add ingestion and effectivity metadata
        df = add_ingestion_metadata(df, True)

        self.df = df
        return df
    

    def apply_scd_type2(self, master_alias: str, existing_df: DataFrame, incoming_df: DataFrame) -> DataFrame:
        """
        Apply SCD Type 2 for both Fabric Lakehouse & Fabric Warehouse.

        Lakehouse (Delta) -> uses Spark logic (unchanged)
        Warehouse (SynapseSQL) -> uses SQL MERGE into the warehouse table
        """

        # -------------------------------------------------------
        # 1️⃣ WAREHOUSE MODE (Synapse SQL — MERGE required)
        # -------------------------------------------------------
        if self.is_warehouse:

            full_table_name = f"{self.target_db}.{self.target_schema}.{self.name}"
            staging_view = f"stg_{self.name}_incoming"
            master_hk_col = master_alias

            # Register incoming DF as temp view
            incoming_df.createOrReplaceTempView(staging_view)

            # Columns not part of change detection
            excluded_cols = {
                f"{self.name}_source_hk",
                "effectivity_start_date",
                "effectivity_end_date",
                "ingestion_timestamp",
            }

            # Dynamically generate change detection predicates
            comparable_cols = [
                c for c in incoming_df.columns if c not in excluded_cols
            ]

            if comparable_cols:
                change_predicates = " OR ".join(
                    [f"t.{c} <> s.{c}" for c in comparable_cols]
                )
            else:
                change_predicates = "1 = 0"   # If no comparable fields, force NO CHANGE

            # Build MERGE SQL for SCD2
            merge_sql = f"""
                MERGE INTO {full_table_name} AS t
                USING {staging_view} AS s
                    ON t.{master_hk_col} = s.{master_hk_col}

                -- 1️⃣ When changed: end-date the existing record
                WHEN MATCHED AND ({change_predicates})
                THEN UPDATE SET 
                    t.effectivity_end_date = CURRENT_TIMESTAMP()

                -- 2️⃣ When changed: insert new version
                WHEN MATCHED AND ({change_predicates})
                THEN INSERT ({", ".join(incoming_df.columns)})
                    VALUES ({", ".join([f"s.{c}" for c in incoming_df.columns])})

                -- 3️⃣ Brand-new rows
                WHEN NOT MATCHED BY TARGET
                THEN INSERT ({", ".join(incoming_df.columns)})
                    VALUES ({", ".join([f"s.{c}" for c in incoming_df.columns])});
            """

            print(f"ℹ️ Running warehouse SCD2 MERGE for {full_table_name}")
            self.spark.sql(merge_sql)

            return None  # Warehouse returns nothing (data is already merged)

        # -------------------------------------------------------
        # 2️⃣ LAKEHOUSE MODE (Delta — Use existing Spark logic)
        # -------------------------------------------------------
        master_hk_col = f"{master_alias}"
        current_ts = F.current_timestamp()

        join_cond = existing_df[master_hk_col] == incoming_df[master_hk_col]

        joined = (
            existing_df.alias("existing")
            .join(incoming_df.alias("incoming"), on=join_cond, how="outer")
        )

        excluded_cols = [
            f"{self.name}_source_hk",
            "effectivity_start_date",
            "effectivity_end_date",
            "ingestion_timestamp",
        ]

        change_conditions = [
            f"existing.{c} != incoming.{c}"
            for c in incoming_df.columns
            if c not in excluded_cols
        ]

        changed_expr = " OR ".join(change_conditions) if change_conditions else "false"
        changed = F.expr(changed_expr)

        updated_existing = (
            joined
            .where(changed & F.col(f"existing.{self.name}_source_hk").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in existing_df.columns])
            .withColumn("effectivity_end_date", current_ts)
        )

        unchanged = (
            joined
            .where(~changed & F.col(f"existing.{self.name}_source_hk").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in existing_df.columns])
        )

        new_records = (
            joined
            .where(F.col(f"existing.{master_hk_col}").isNull())
            .select(*[F.col(f"incoming.{c}") for c in incoming_df.columns])
            .withColumn(
                "effectivity_start_date",
                F.when(
                    F.col("incoming.effectivity_start_date").isNotNull(),
                    F.col("incoming.effectivity_start_date")
                ).otherwise(current_ts)
            )
            .withColumn(
                "effectivity_end_date",
                F.when(
                    F.col("incoming.effectivity_end_date").isNotNull(),
                    F.col("incoming.effectivity_end_date")
                ).otherwise(F.lit(None).cast("timestamp"))
            )
        )

        new_versions = (
            joined
            .where(changed & F.col(f"existing.{hk_col}").isNotNull())
            .select(*[F.col(f"incoming.{c}") for c in incoming_df.columns])
            .withColumn("effectivity_start_date", current_ts)
            .withColumn("effectivity_end_date", F.lit(None).cast("timestamp"))
        )
        

        if self.write_method == "append":
            return updated_existing.unionByName(new_versions).unionByName(new_records)
        else:  # overwrite
            return unchanged.unionByName(new_versions).unionByName(new_records)


    def write_ingestion_log(self, df_log):
        pass

    def get_partition_keys(self):
        return self.business_keys

    def set_tbl_properties(self):
        self.spark.sql(f"""
            ALTER TABLE {self.target_schema}.{self.target_db}.{self.name}
            SET TBLPROPERTIES (
            'primaryKey' = {self.primary_key},
            'masterKeys' = {[m[0] for m in self.master_links]}
            'lastUpdatedBy' = 'FabricPipeline'
            )
            """)