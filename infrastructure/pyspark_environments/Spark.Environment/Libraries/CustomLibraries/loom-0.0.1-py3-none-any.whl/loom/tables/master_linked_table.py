from typing import List, Tuple
from pyspark.sql import DataFrame, SparkSession
from .base_table import BaseTable
from .table_type import TableType
from loom.utils.metadata import add_ingestion_metadata
from typing import Callable

import pyspark.sql.functions as F
from functools import reduce

class MasterLinkedTable(BaseTable):
    """
    MasterLinkedTable extends KeyedTable to support linking one dataset to multiple
    master datasets (e.g. Product Master, Customer Master, etc.).

    Each master link is a tuple of:
        (alias, master_df, business_key, primary_key_col)

    Example:
        sales_table = MasterLinkedTable(
            name="sales_order_line",
            df=sales_df,
            business_keys=["salesorderlineid"],
            primary_keys=["salesorderlineid","lineno"],
            master_links=[
                ("product_master_hk", product_master_df, "productcode", "proudct_source_hk", [{"field": "field2"}])
            ]
            is_warehouse=True
        )
    """

    def __init__(
        self,
        name: str,
        df: DataFrame,
        existing_df: DataFrame,
        schema_evolution: bool,
        target_path: str,
        target_db: str = None,
        target_schema: str = None,
        transform: Callable = None,
        business_keys: List[str] = [],
        primary_key: str = None,
        master_links: List[Tuple[str, DataFrame, str, str]] = [],
        is_warehouse: bool = False,
        spark: SparkSession = SparkSession.builder.appName("MasterLinkedTable").getOrCreate()
    ):
        super().__init__(name, TableType.MASTERLINKED, df, schema_evolution,  target_path=target_path, target_schema=target_schema, target_db=target_db, is_warehouse=is_warehouse, spark=spark)
        self.master_links = master_links
        self.existing_df = existing_df
        self.transform = transform
        self.primary_key = primary_key
        self.business_keys = business_keys


    def prepare(self) -> DataFrame:
        """
        Prepare the table for ingestion:
        - Join all master mappings
        - Replace missing master keys with sha2('-1', 256)
        - Materialize selected master fields
        - Add metadata fields for audit and effectivity tracking
        """
        df = self.df

        for master_alias, master_df, key_col, materialized_fields in self.master_links:

            fk_col = key_col.replace("_hk", "_fk")

            if key_col in df.columns: 
                # Join master dataframe on key (primary)
                df = df.join(master_df, on=key_col, how="left")
            
                # Replace missing master keys with SHA2('-1', 256)
                df = df.withColumn(
                    master_alias,
                    F.when(F.col(master_alias).isNotNull(), F.col(master_alias))
                    .otherwise(F.sha2(F.lit("-1"), 256))
                )

                #  Materialize master fields if master key exists
                for col in materialized_fields:
                    df = df.withColumn(
                        col,
                        F.when(F.col(master_alias) != F.sha2(F.lit("-1"), 256), F.col(col))
                    )

            elif fk_col in df.columns:
                # Join on foreign key to get master key, 
                # but there is no materialized columns in this case
                df = df.join(master_df, master_df[key_col] == df[fk_col], how="left")

                fk_master_alias = master_alias.replace("_hk", "_fk")
                
                df = df.withColumn(
                    fk_master_alias,
                    F.when(F.col(master_alias).isNotNull(), F.col(fk_master_alias))
                    .otherwise(F.sha2(F.lit("-1"), 256))
                )


        # 6️⃣ Add ingestion and effectivity metadata
        df = add_ingestion_metadata(df, True)

        self.df = df
        return df
    

    def apply_scd_type2(self, incoming_df: DataFrame) -> DataFrame:
        """
        Apply SCD Type 2 for both Fabric Lakehouse & Fabric Warehouse.

        Lakehouse (Delta) -> uses Spark logic (unchanged)
        Warehouse (SynapseSQL) -> uses SQL MERGE into the warehouse table
        """

        # -------------------------------------------------------
        # 1️⃣ WAREHOUSE MODE (Synapse SQL — MERGE required)
        # -------------------------------------------------------
        if self.is_warehouse:

            master_hk_col = self.master_links[0][0]

            excluded_cols = {
                f"{self.name}_source_hk",
                "effectivity_start_date",
                "effectivity_end_date",
                "ingestion_timestamp",
                "unmapped"
            }

            comparable_cols = [
                c for c in incoming_df.columns if c not in excluded_cols
            ]

            # Alias
            if self.existing_df.rdd.isEmpty():
                final_df = incoming_df
            
            else:
                s = incoming_df.alias("s")
                t = self.existing_df.alias("t")

                 # Join on business key
                joined = t.join(s, master_hk_col, "fullouter")

                # Build change condition
                if comparable_cols:
                    change_cond = reduce(
                        lambda a, b: a | b,
                        [F.col(f"t.{c}") != F.col(f"s.{c}") for c in comparable_cols],
                    )
                else:
                    change_cond = F.lit(False)

                # 1️⃣ End-date changed existing records
                expired_records = (
                    joined
                    .filter(
                        F.col(f"t.{master_hk_col}").isNotNull() &
                        F.col(f"s.{master_hk_col}").isNotNull() &
                        change_cond
                    )
                    .select("t.*")
                    .withColumn(
                        "effectivity_end_date",
                        F.current_timestamp()
                    )
                )

                # 2️⃣ New versions of changed records
                new_versions = (
                    joined
                    .filter(
                        F.col(f"t.{master_hk_col}").isNotNull() &
                        F.col(f"s.{master_hk_col}").isNotNull() &
                        change_cond
                    )
                    .select("s.*")
                )

                # 3️⃣ Brand-new records
                new_records = (
                    joined
                    .filter(
                        F.col(f"t.{master_hk_col}").isNull() &
                        F.col(f"s.{master_hk_col}").isNotNull()
                    )
                    .select("s.*")
                )

                # 4️⃣ Unchanged existing records
                unchanged_records = (
                    joined
                    .filter(
                        F.col(f"t.{master_hk_col}").isNotNull() &
                        (
                            F.col(f"s.{master_hk_col}").isNull() |
                            ~change_cond
                        )
                    )
                    .select("t.*")
                )

                # Final SCD2 table
                final_df = (
                    unchanged_records
                    .unionByName(expired_records, allowMissingColumns=True)
                    .unionByName(new_versions, allowMissingColumns=True)
                    .unionByName(new_records, allowMissingColumns=True)
                )

            return final_df

             # Warehouse returns nothing (data is already merged)

        # -------------------------------------------------------
        # 2️⃣ LAKEHOUSE MODE (Delta — Use existing Spark logic)
        # -------------------------------------------------------
        master_hk_col = self.master_links[0][0]
        current_ts = F.current_timestamp()

        join_cond = self.existing_df[master_hk_col] == incoming_df[master_hk_col]

        joined = (
            self.existing_df.alias("existing")
            .join(incoming_df.alias("incoming"), on=join_cond, how="outer")
        )

        excluded_cols = [
            f"{self.name}_source_hk",
            "effectivity_start_date",
            "effectivity_end_date",
            "ingestion_timestamp",
            "unmapped"
        ]

        change_conditions = [
            f"existing.{c} != incoming.{c}"
            for c in incoming_df.columns
            if c not in excluded_cols
        ]

        changed_expr = " OR ".join(change_conditions) if change_conditions else "false"
        changed = F.expr(changed_expr)

        updated_existing = (
            joined
            .where(changed & F.col(f"existing.{self.name}_source_hk").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in self.existing_df.columns])
            .withColumn("effectivity_end_date", current_ts)
        )

        unchanged = (
            joined
            .where(~changed & F.col(f"existing.{self.name}_source_hk").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in self.existing_df.columns])
        )

        new_records = (
            joined
            .where(F.col(f"existing.{master_hk_col}").isNull())
            .select(*[F.col(f"incoming.{c}") for c in incoming_df.columns])
            .withColumn(
                "effectivity_start_date",
                F.when(
                    F.col("incoming.effectivity_start_date").isNotNull(),
                    F.col("incoming.effectivity_start_date")
                ).otherwise(current_ts)
            )
            .withColumn(
                "effectivity_end_date",
                F.when(
                    F.col("incoming.effectivity_end_date").isNotNull(),
                    F.col("incoming.effectivity_end_date")
                ).otherwise(F.lit(None).cast("timestamp"))
            )
        )

        new_versions = (
            joined
            .where(changed & F.col(f"existing.{master_hk_col}").isNotNull())
            .select(*[F.col(f"incoming.{c}") for c in incoming_df.columns])
            .withColumn("effectivity_start_date", current_ts)
            .withColumn("effectivity_end_date", F.lit(None).cast("timestamp"))
        )
        

        if self.write_method == "append":
            return updated_existing.unionByName(new_versions).unionByName(new_records)
        else:  # overwrite
            return unchanged.unionByName(new_versions).unionByName(new_records)


    def write_ingestion_log(self, df_log):
        pass

    def get_partition_keys(self):
        return self.business_keys

    def set_tbl_properties(self):
        self.spark.sql(f"""
            ALTER TABLE {self.target_schema}.{self.target_db}.{self.name}
            SET TBLPROPERTIES (
            'primaryKey' = {self.primary_key},
            'masterKeys' = {[m[0] for m in self.master_links]}
            'lastUpdatedBy' = 'FabricPipeline'
            )
            """)