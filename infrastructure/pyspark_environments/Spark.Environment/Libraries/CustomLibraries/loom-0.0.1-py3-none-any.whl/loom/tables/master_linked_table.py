from typing import List, Tuple
from pyspark.sql import DataFrame
from .base_table import BaseTable
from .table_type import TableType
from loom.utils.metadata import add_ingestion_metadata
from typing import Callable

import pyspark.sql.functions as F

class MasterLinkedTable(BaseTable):
    """
    MasterLinkedTable extends KeyedTable to support linking one dataset to multiple
    master datasets (e.g. Product Master, Customer Master, etc.).

    Each master link is a tuple of:
        (alias, master_df, business_key, master_key_col)

    Example:
        sales_table = MasterLinkedTable(
            name="sales_order_line",
            df=sales_df,
            business_keys=["salesorderlineid"],
            primary_keys=["salesorderlineid","lineno"],
            master_links=[
                ("product_master_hk", product_master_df, "productcode", "proudct_source_hk", [{"field": "field2"}])
            ]
        )
    """

    def __init__(
        self,
        name: str,
        df: DataFrame,
        schema_evolution: bool,
        target_path: str,
        target_db: str = None,
        target_schema: str = None,
        transform: Callable = None,
        business_keys: List[str] = [],
        primary_key: str = None,
        master_links: List[Tuple[str, DataFrame, str, str]] = [],
    ):
        super().__init__(name, TableType.MASTERLINKED, df, schema_evolution,  target_path=target_path, target_schema=target_schema, target_db=target_db)
        self.master_links = master_links
        self.transform = transform
        self.primary_key = primary_key
        self.business_keys = business_keys

    def prepare(self) -> DataFrame:
        """
        Prepare the table for ingestion:
        - Join all master mappings
        - Replace missing master keys with sha2('-1', 256)
        - Add metadata fields for audit and effectivity tracking
        """
        df = self.df

        for master_alias, master_df, business_key, master_key_col, materialized_fields in self.master_links:
            # 1️⃣ Prepare lookup dataframe (only needed cols)
            lookup_cols = [business_key, master_key_col] + [list(f.values())[0] for f in materialized_fields]
            lookup_df = master_df.select(*lookup_cols)

            # 2️⃣ Build rename mapping for descriptive fields
            rename_map = {}
            for mapping in materialized_fields:
                for target_field, source_field in mapping.items():
                    rename_map[source_field] = target_field  # e.g. "name" -> "ProductName"

            # 3️⃣ Rename descriptive columns
            for src_col, tgt_col in rename_map.items():
                lookup_df = lookup_df.withColumnRenamed(src_col, tgt_col)

            # 4️⃣ Join master table to base df
            df = df.join(lookup_df, on=business_key, how="left")

            # 5️⃣ Materialize master key (e.g. product_master_hk = product_hk)
            df = df.withColumn(master_alias, F.col(master_key_col))

            # 6️⃣ Replace missing master keys with sha2('-1', 256)
            df = df.withColumn(
                master_alias,
                F.when(F.col(master_alias).isNotNull(), F.col(master_alias))
                .otherwise(F.sha2(F.lit("-1"), 256))
            )

            # 7️⃣ Only materialize/update lookup fields if the master key exists
            for mapping in materialized_fields:
                for target_field, _ in mapping.items():
                    df = df.withColumn(
                        target_field,
                        F.when(F.col(master_alias) != F.sha2(F.lit("-1"), 256), F.col(target_field))
                        .otherwise(F.col(target_field))  # keep original if missing
                    )

        # 8️⃣ Add ingestion and effectivity metadata
        df = add_ingestion_metadata(df, True)

        self.df = df
        return df
    

    def apply_scd_type2(self, master_alias: str, existing_df: DataFrame, incoming_df: DataFrame) -> DataFrame:
        """
        Apply Slowly Changing Dimension (SCD Type 2) logic dynamically per master alias.
        End-dates old records and inserts new versions when dimension values change.
        """

        # Dynamic column names
        master_hk_col = f"{master_alias}"

        # Current timestamp
        current_ts = F.current_timestamp()

        # Join on master hash key
        join_cond = [existing_df[master_hk_col] == incoming_df[master_hk_col]]

        joined = existing_df.alias("existing").join(
            incoming_df.alias("incoming"),
            on=join_cond,
            how="outer"
        )

        # Columns to exclude from change detection
        excluded_cols = [
            f"{self.name}_source_hk",
            "effectivity_start_date",
            "effectivity_end_date",
            "ingestion_timestamp"
        ]

        # Detect changes
        changed_expr = " OR ".join([
            f"existing.{c} != incoming.{c}"
            for c in incoming_df.columns if c not in excluded_cols
        ])
        changed = F.expr(changed_expr)

        # Existing records that have changed — end-date them
        updated_existing = (
            joined
            .where(changed & F.col(f"existing.{self.name}_source_hk").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in existing_df.columns])
            .withColumn("effectivity_end_date", current_ts)
        )

        # Existing records that haven’t changed — keep them as-is
        unchanged = (
            joined
            .where(~changed & F.col(f"existing.{self.name}_source_hk").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in existing_df.columns])
        )

        # New or changed incoming records — insert new versions
        new_or_changed = (
            joined
            .where(changed | F.col(f"existing.{master_hk_col}").isNull())
            .select(*[F.col(f"incoming.{c}") for c in incoming_df.columns])
            .withColumn(
                "effectivity_start_date",
                F.when(
                    F.col("incoming.effectivity_start_date").isNotNull(),
                    F.col("incoming.effectivity_start_date")
                ).otherwise(current_ts)
            )
            .withColumn(
                "effectivity_end_date",
                F.when(
                    F.col("incoming.effectivity_end_date").isNotNull(),
                    F.col("incoming.effectivity_end_date")
                ).otherwise(F.lit(None).cast("timestamp"))
            )
        )

        # Combine all sets
        result_df = updated_existing.unionByName(unchanged).unionByName(new_or_changed)

        return result_df


    def write_ingestion_log(self):
        pass

    def get_partition_keys(self):
        return self.business_keys

    def set_tbl_properties(self):
        self.spark.sql(f"""
            ALTER TABLE {self.target_schema}.{self.target_db}.{self.name}
            SET TBLPROPERTIES (
            'primaryKey' = {self.primary_key},
            'masterKeys' = {[m[0] for m in self.master_links]}
            'lastUpdatedBy' = 'FabricPipeline'
            )
            """)