from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import *
from abc import ABC, abstractmethod
from typing import Optional, Callable
from pyspark.sql.functions import lit
from loom.tables.table_type  import TableType


class BaseTable(ABC):
    """
    Base class for all Loom table types.

    Provides:
      - common structure for all tables (name, DataFrame, schema)
      - a consistent interface (`prepare()`)
      - support for saving DataFrames to target locations (delta, parquet, etc.)
    """

    def __init__(
        self,
        name: str | None,
        table_type: TableType| None,
        df: DataFrame | None = None,
        transform: Callable = None, 
        schema_evolution: bool = False,
        write_method: Optional[str] = "append",
        target_db: str = None,
        target_schema: str = None,
        target_path: Optional[str] = None,
        format: str = "delta",
        is_warehouse: bool = False
    ):
        """
        :param target_schema: Target Highlevel (generally dbo)
        :param target_db: Target Database name
        :param name: Logical name of the table (e.g. 'sales_orders')
        :param df: Input PySpark DataFrame
        :param schema_evolution: Allow for Slowly changing dimensions
        :param table_type: the table type to be ingested 
        :param transform: the function to the perform transformations and deduplication
        :param write_method: Optional input overload for determining how the table will be written to the lakehouse/datawarehouse (default is append)
        :param target_path: Optional output location for saving
        :param format: File format for saving ('delta', 'parquet', etc.)
        :param is_warehouse: whether it is a fabric warehouse or not
        """
        self.target_schema = target_schema
        self.target_db = target_db
        self.name = name
        self.df = df
        self.schema_evolution=  schema_evolution
        self.write_method = write_method
        self.target_path = target_path
        self.format = format
        self.table_type = table_type
        self.transform = transform
        self.is_warehouse = is_warehouse
        self.spark = SparkSession.builder.getOrCreate()

    @abstractmethod
    def prepare(self) -> DataFrame:
        """
        Abstract method for preparing and validating the DataFrame.
        Subclasses must implement this to handle:
            - metadata addition
            - key generation
        """
        pass

    @abstractmethod
    def set_tbl_properties(self):
        pass

    @abstractmethod
    def get_partition_keys(self):
        return []
    
    @abstractmethod
    def write_ingestion_log(self, df_log) -> None:
        pass

    @abstractmethod
    def apply_scd_type2(self):
        pass

    def validate_schema(self):
        """Ensures that the DataFrame is valid and has columns."""
        if self.df is None:
            raise ValueError(f"Table '{self.target_schema}.{self.target_db}.{self.name}' has no DataFrame assigned.")
        if len(self.df.columns) == 0:
            raise ValueError(f"Table '{self.target_schema}.{self.target_db}.{self.name}' DataFrame has no columns.")

    def show_schema(self):
        """Display the schema for inspection."""
        print(f"Schema for table '{self.name}':")
        self.df.printSchema()

    def preview(self, n: int = 10):
        """Show sample data for quick inspection."""
        print(f"Preview of '{self.target_schema}.{self.target_db}.{self.name}' (first {n} rows):")
        self.df.show(n)

    def write(self):
        """
        Save the prepared DataFrame to lakehouse or fabric warehouse.
        """
        # -----------------------------
        #   1. FABRIC WAREHOUSE MODE
        # -----------------------------
        if self.is_warehouse:

            fqtn = f"{self.target_schema}.{self.target_db}.{self.name}"

            # --------------------------------
            # Check if Warehouse table exists
            # --------------------------------
            table_exists = self.spark.catalog.tableExists(fqtn)

            # --------------------------------
            # SCD2 merge path
            # --------------------------------
            if table_exists and self.table_type in {
                TableType.KEYED,
                TableType.MASTERLINKED
            }:
                print(f"ℹ️ Applying SCD2 merge into warehouse table {fqtn}")

                # Your SCD2 logic should emit MERGE SQL
                self.apply_scd_type2(
                    existing_df=None,   # warehouse-side
                    incoming_df=self.df
                )

                self.set_tbl_properties()

            else:
                # --------------------------------
                # Initial load / overwrite
                # --------------------------------
                print(f"ℹ️ Writing initial load to warehouse {fqtn}")

                self.df.createOrReplaceTempView(f"_staging_{self.name}")

                if self.write_method == "overwrite" or not table_exists:
                    self.spark.sql(f"""
                        CREATE OR REPLACE TABLE {fqtn}
                        AS SELECT * FROM _staging_{self.name}
                    """)
                else:
                    self.spark.sql(f"""
                        INSERT INTO {fqtn}
                        SELECT * FROM _staging_{self.name}
                    """)

                self.set_tbl_properties()
                print(f"✅ Warehouse table '{fqtn}' written successfully")

        # -----------------------------------
        #   2. LAKEHOUSE MODE
        # -----------------------------------
        else:

            # Realigning columns before ingestion
            if self.spark.catalog.tableExists(self.name):
                target_df = self.spark.read.table(self.name)
                target_schema = target_df.schema

                aligned_cols = []

                for field in target_schema:
                    col_name = field.name
                    col_type = field.dataType

                    if col_name in self.df.columns:
                        # Cast existing column to target type
                        aligned_cols.append(col(col_name).cast(col_type).alias(col_name))
                    else:
                        # Add missing column with correct type
                        aligned_cols.append(lit(None).cast(col_type).alias(col_name))

                # Select only target columns, in target order
                self.df = self.df.select(*aligned_cols)

            # ------------------------
            # Apply SCD2
            # ------------------------
            if self.table_type in {TableType.KEYED, TableType.MASTERLINKED}:

                try:
                    existing_df = self.spark.read.table(self.name)
                    print(f"ℹ️ Existing data found for '{self.name}', applying SCD Type 2 merge...")
                    self.df = self.apply_scd_type2(existing_df, self.df)

                except Exception:
                    print(f"⚠️ No existing data found for '{self.name}'. Initial load only.")

                # Write lakehouse keyed/master table
                writer = (
                    self.df.write
                    .format(self.format)
                    .option("mergeSchema", self.schema_evolution)
                    .mode(self.write_method)
                )

                if self.get_partition_keys() is not None and len(self.get_partition_keys()) > 0:
                    writer = writer.partitionBy(self.get_partition_keys())

                writer.saveAsTable(f"{self.target_schema}.{self.target_db}.{self.name}")

                self.set_tbl_properties()

                print(f"✅ Lakehouse Keyed/Master table '{self.target_schema}.{self.target_db}.{self.name}' successfully saved.")

            else:
                # ------------------------
                # Plain Lakehouse write
                # ------------------------
                INGESTION_LOG_SCHEMA = StructType([
                    StructField("source_file", StringType(), False),
                    StructField("source_system", StringType(), False),
                    StructField("ingestion_timestamp", TimestampType(), False),
                ])

                rows = (
                    self.df
                    .select("source_file", "source_system", "ingestion_timestamp")
                    .distinct()
                    .collect()
                )
                print("Number of Ingestion log rows", len(rows))

                df_log = self.spark.createDataFrame(rows, INGESTION_LOG_SCHEMA)


                if self.get_partition_keys() is not None and len(self.get_partition_keys()) > 0:
                    (
                        self.df.write
                        .format(self.format)
                        .option("mergeSchema", self.schema_evolution)
                        .partitionBy(self.get_partition_keys())
                        .mode(self.write_method)
                        .saveAsTable(f"{self.target_schema}.{self.target_db}.{self.name}")
                    )
                else:
                    (
                        self.df.write
                        .format(self.format)
                        .option("mergeSchema", self.schema_evolution)
                        .mode(self.write_method)
                        .saveAsTable(f"{self.target_schema}.{self.target_db}.{self.name}")
                    )

                self.write_ingestion_log(df_log)
                print(f"✅ Lakehouse Plain table '{self.target_schema}.{self.target_db}.{self.name}' successfully saved.")

    def count(self) -> int:
        """Returns the number of records."""
        return self.df.count()

    def cache(self):
        """Caches the DataFrame for reuse."""
        self.df.cache()
        print(f"🔒 Cached table '{self.name}'")
        return self.df
