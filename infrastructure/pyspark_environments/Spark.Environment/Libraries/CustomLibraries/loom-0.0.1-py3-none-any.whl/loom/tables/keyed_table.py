from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import TimestampType
from typing import List


from .base_table import BaseTable
from .table_type import TableType
from loom.utils.metadata import add_ingestion_metadata
from loom.utils.validation import assert_no_duplicates
from typing import Callable
from pyspark.sql import SparkSession

class KeyedTable(BaseTable):
    """
    Represents a dataset with defined business and primary keys.

    Automatically:
      - Checks for duplicate primary keys
      - Generates SHA2-256 hash primary key (if not present)
      - Adds ingestion and effectivity metadata fields

    Transform function
      - Used to for mapping to target schema
      - Modifying field types, doing calculations that need to be materialised etc.
    
    Deduplication function
      - This should be used to identify if there is duplicate record (based of the business keys/primary key) 
        within a source and create a mapping between these fields ie: recordA and recordB map to recordC

    

    Example:
        customers_table = KeyedTable(
            name="customers",
            df=customers_df,
            business_keys=["locationcode", "country"],
            source_primary_keys=["customerid", "source_system", "company"],
            source_foreign_keys=[{"location": ["locationcode", "source_system", "company"]}]
            transform=None,
            deduplicate=None
        )
    """

    def __init__(
        self,
        target_db: str,
        target_schema: str,
        name: str,
        schema_evolution: bool,
        df: DataFrame,
        target_path: str,
        business_keys: List[str],
        source_primary_keys: List[str],
        source_foreign_keys: List[str],
        transform: Callable,
        deduplicate: Callable
    ):
        super().__init__(name, TableType.KEYED, df, schema_evolution=schema_evolution, target_path=target_path, target_db=target_db, target_schema=target_schema)
        self.business_keys = business_keys
        self.source_primary_keys = source_primary_keys
        self.source_foreign_keys = source_foreign_keys
        self.transform = transform
        self.deduplicate = deduplicate

    def prepare(self) -> DataFrame:
        """
        Prepare the keyed dataset for ingestion:
        - Generate primary key hash if missing
        - Check for duplicates on primary key hash
        - Add standard metadata fields
        """
        df = self.df

        # transform the dataframe
        if self.transform is not None:
            self.transform(df)

        # Checking source primary keys
        for key in self.source_primary_keys:
            if key not in df.columns:
                raise ValueError(f"Source primary key column '{key}' not found in DataFrame")

        # Generate a composite SHA2-256 primary key if multiple columns exist
        if len(self.source_primary_keys) > 1:
            concat_expr = F.concat_ws("||", *[F.col(k).cast("string") for k in self.source_primary_keys])
        else:
            concat_expr = F.col(self.source_primary_keys[0]).cast("string")

        # Generate the hash primary key
        df = df.withColumn(f"{self.name}_source_hk", F.sha2(F.concat_ws("||", concat_expr), 256))

        # Generate the hash foreign keys
        for mapping in self.source_foreign_keys:
            for table_name, cols in mapping.items():
                df = df.withColumn(
                    f"{table_name}_source_fk",
                    F.sha2(F.concat_ws("|", *[F.col(c) for c in cols]), 256)
                )

        #  Deduplicate 
        if self.deduplicate is not None:
            df = self.deduplicate(df)
            df = df.withColumn("ingestion_timestamp", F.current_timestamp())
        else:
            # Add metadata fields
            df = add_ingestion_metadata(df, True)

        # Check that there are no duplicates in the table, raises exception if there is
        assert_no_duplicates(df, [f"{self.name}_hk", "effectivity_end_date"])

        self.df = df
        return df
    
    def get_partition_keys(self):
        return self.business_keys

    def write_ingestion_log(self):
        pass

    def set_tbl_properties(self):
        self.spark.sql(f"""
            ALTER TABLE {self.target_schema}.{self.target_db}.{self.name}
            SET TBLPROPERTIES (
            'primaryKey' = {self.name}_hk,
            'businessKeys' = {self.business_keys}
            'lastUpdatedBy' = 'FabricPipeline'
            )
            """)
    
    def apply_scd_type2(self, existing_df: DataFrame, incoming_df: DataFrame) -> DataFrame:
        """
        Apply Slowly Changing Dimension (SCD Type 2) logic.
        End-dates old records and inserts new versions when dimension values change.
        """

        # Current timestamp
        current_ts = F.current_timestamp()

        # Join on the primary key hash
        join_cond = [existing_df[f"{self.name}_hk"] == incoming_df[f"{self.name}_hk"]]

        joined = existing_df.alias("existing").join(
            incoming_df.alias("incoming"),
            on=join_cond,
            how="outer"
        )

        # Flag to indicate whether data changed
        changed = F.expr(
            " OR ".join([
                f"existing.{c} != incoming.{c}" for c in incoming_df.columns
                if c not in [f"{self.name}_hk", "effectivity_start_date", "effectivity_end_date", "ingestion_timestamp"]
            ])
        )

        # End-date old records when changed
        updated_existing = (
            joined
            .where(changed & F.col(f"existing.{self.name}_hk").isNotNull())
            .select(
                *[F.col(f"existing.{c}") for c in existing_df.columns],
            )
            .withColumn("effectivity_end_date", current_ts)
        )

        # Keep unchanged records
        unchanged = (
            joined
            .where(~changed & F.col(f"existing.{self.name}_hk").isNotNull())
            .select(
                *[F.col(f"existing.{c}") for c in existing_df.columns],
            )
        )

        # Insert new versions (changed or new records)
        new_or_changed = (
            joined
            .where(changed | F.col(f"existing.{self.name}_hk").isNull())
            .select(
                *[F.col(f"incoming.{c}") for c in incoming_df.columns],
            )
            .withColumn("effectivity_start_date", current_ts)
            .withColumn("effectivity_end_date", F.lit(None).cast("timestamp"))
        )

        # Combine all results
        return updated_existing.unionByName(unchanged).unionByName(new_or_changed)