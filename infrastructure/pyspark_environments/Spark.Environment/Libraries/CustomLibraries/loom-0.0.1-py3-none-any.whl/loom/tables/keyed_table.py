from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import MapType, StructType, ArrayType
from typing import List, Optional
from delta.tables import DeltaTable
from pyspark.sql.window import Window


from .base_table import BaseTable
from .table_type import TableType
from loom.utils.metadata import add_ingestion_metadata
from loom.utils.validation import assert_no_duplicate_active_records
from typing import Callable
from pyspark.sql import SparkSession

class KeyedTable(BaseTable):
    """
    Represents a dataset with defined business and primary keys.

    Automatically:
      - Checks for duplicate primary keys
      - Generates SHA2-256 hash primary key (if not present)
      - Adds ingestion and effectivity metadata fields

    Transform function
      - Used to for mapping to target schema
      - Modifying field types, doing calculations that need to be materialised etc.
    
    Deduplication function
      - This should be used to identify if there is duplicate record (based of the business keys/primary key) 
        within a source and create a mapping between these fields ie: recordA and recordB map to recordC

    

    Example:
        customers_table = KeyedTable(
            name="customers",
            df=customers_df,
            business_keys=["locationcode", "country"],
            source_primary_keys=["customerid", "source_system", "company"],
            source_foreign_keys=[{"location": ["locationcode", "source_system", "company"]}]
            transform=None,
            deduplicate=None
        )
    """

    def __init__(
        self,
        target_db: str,
        target_schema: str,
        name: str,
        schema_evolution: bool,
        df: DataFrame,
        target_path: str,
        business_keys: List[str],
        source_primary_keys: List[str],
        source_foreign_keys: List[str],
        transform: Callable,
        deduplicate: Callable,
        write_method: Optional[str] = "append"
    ):
        super().__init__(name, TableType.KEYED, df, schema_evolution=schema_evolution, target_path=target_path, target_db=target_db, target_schema=target_schema, write_method=write_method)
        self.business_keys = business_keys
        self.source_primary_keys = source_primary_keys
        self.source_foreign_keys = source_foreign_keys
        self.transform = transform
        self.deduplicate = deduplicate

    def prepare(self) -> DataFrame:
        """
        Prepare the keyed dataset for ingestion:
        - Generate primary key hash if missing
        - Check for duplicates on primary key hash
        - Add standard metadata fields
        """
        df = self.df

        # transform the dataframe
        if self.transform is not None:
            df = self.transform(df)

        # Checking source primary keys
        for key in self.source_primary_keys:
            if key not in df.columns:
                raise ValueError(f"Source primary key column '{key}' not found in DataFrame")

        # Generate a composite SHA2-256 primary key if multiple columns exist
        if len(self.source_primary_keys) > 1:
            concat_expr = F.concat_ws("||", *[F.col(k).cast("string") for k in self.source_primary_keys])
        else:
            concat_expr = F.col(self.source_primary_keys[0]).cast("string")

        #Generate the hash primary key
        df = df.withColumn(f"{self.name}_source_hk", F.sha2(F.concat_ws("||", concat_expr), 256))

        # Generate the hash foreign keys
        for mapping in self.source_foreign_keys:
            for table_name, cols in mapping.items():
                try:
                    df = df.withColumn(
                        f"{table_name}_source_fk",
                        F.sha2(F.concat_ws("|", *[F.col(c) for c in cols]), 256)
                    )
                except:
                    print(f"WARNING: One of the Foreign Key columns {cols} doesn't exist in the table")

        #  Deduplicate 
        if self.deduplicate is not None:
            df = df.withColumn("ingestion_timestamp", F.current_timestamp())
            df = self.deduplicate(df)
        else:
            # Add metadata fields
            df = add_ingestion_metadata(df, True)


        # rename the company field so it is less confusing with the SCD2 information.
        df = df.withColumnRenamed("company", "originating_company")

        # Check that there are no duplicates in the table, raises exception if there is
        assert_no_duplicate_active_records(df, "effectivity_end_date", [f"{self.name}_hk", "effectivity_end_date"])

        self.df = df
        return self.df
    
    def get_partition_keys(self):
        return self.business_keys

    def write_ingestion_log(self, df_log):
        pass

    def set_tbl_properties(self):
        self.spark.sql(f"""
            ALTER TABLE {self.target_schema}.{self.target_db}.{self.name}
            SET TBLPROPERTIES (
            'primaryKey' = '{self.name}_hk',
            'businessKeys' = '{','.join(self.business_keys)}',
            'lastUpdatedBy' = 'FabricPipeline'
            )
            """)
    
    def build_change_condition(self, existing_df, incoming_df, hk_col):
        excluded = {
            hk_col,
            "effectivity_start_date",
            "effectivity_end_date",
            "ingestion_timestamp",
            "unmapped"
        }

        existing_schema = {f.name: f.dataType for f in existing_df.schema.fields}
        incoming_schema = {f.name: f.dataType for f in incoming_df.schema.fields}

        comparable_cols = []

        for col_name, dtype in incoming_schema.items():
            if col_name in excluded:
                continue
            if col_name not in existing_schema:
                continue
            if isinstance(dtype, (MapType, ArrayType, StructType)):
                continue

            comparable_cols.append(col_name)

        if not comparable_cols:
            return "false"

        return " OR ".join(
            [f"NOT (tgt.`{c}` <=> src.`{c}`)" for c in comparable_cols]
        )

    def apply_scd_type2(self, incoming_df: DataFrame, dedup_cols=None) -> None:
        """
        Apply Slowly Changing Dimension (SCD Type 2) logic.
        
        APPEND:
            - return changed (end-dated existing)
            - return new rows only
        
        OVERWRITE:
            - return unchanged existing
            - return new rows
        """

        target_table = f"{self.target_schema}.{self.target_db}.{self.name}"
        hk_col = f"{self.name}_hk"
        current_ts = F.current_timestamp()

        delta_table = DeltaTable.forName(self.spark, target_table).alias("tgt")

        src = incoming_df.alias("src")

        change_condition = self.build_change_condition(
            delta_table.toDF(),
            src,
            hk_col
        )

        join_condition = f"src.{hk_col} = tgt.{hk_col}"

        if dedup_cols is None:
            dedup_cols = ["effectivity_start_date", "effectivity_end_date"]


        w = Window.partitionBy(hk_col).orderBy(*[F.desc(c) for c in dedup_cols])
        deduped_src = (
            incoming_df
            .withColumn("row_rank", F.row_number().over(w))
            .filter(F.col("row_rank") == 1)
            .drop("row_rank")
        )

        dup_check = (
           deduped_src
            .groupBy(hk_col)
            .count()
            .filter(F.col("count") > 1)
        )    

        if dup_check.limit(1).count() > 0:
            columns = ",".join(dedup_cols)
            raise ValueError(f"Source Dataframe still contains duplicate primary keys with the same {columns} columns after dedup")


        bad_target = (
            delta_table.toDF()
            .filter(F.col("effectivity_end_date").isNull())
            .groupBy(hk_col)
            .count()
            .filter(F.col("count") > 1)
        )

        if bad_target.limit(1).count() > 0:
            bad_target.show()
            raise RuntimeError(f"{target_table} has multiple active rows per primary key")

        # -----------------------------
        # 4️⃣ Expire existing rows (SCD2 logic)
        # -----------------------------
        delta_table.merge(
            source=deduped_src,
            condition=f"{join_condition} AND tgt.effectivity_end_date IS NULL"
        ).whenMatchedUpdate(
            condition=change_condition,
            set={"effectivity_end_date": current_ts}
        ).execute()

        # -----------------------------
        # 5️⃣ Insert new/changed rows
        # -----------------------------
        insert_df = (
            deduped_src
            .withColumn("effectivity_start_date", F.coalesce(F.col("effectivity_start_date"), current_ts))
            .withColumn("effectivity_end_date", F.lit(None).cast("timestamp"))
        )

        delta_table.merge(
            source=insert_df.alias("src"),
            condition=join_condition
        ).whenNotMatchedInsertAll().execute()

        print(f"✅ SCD2 merge completed for table {target_table}")
