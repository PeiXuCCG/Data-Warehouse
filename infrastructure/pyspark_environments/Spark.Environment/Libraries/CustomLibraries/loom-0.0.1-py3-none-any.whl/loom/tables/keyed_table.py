from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import TimestampType
from typing import List


from .base_table import BaseTable
from .table_type import TableType
from loom.utils.metadata import add_ingestion_metadata
from loom.utils.validation import assert_no_duplicate_active_records
from typing import Callable
from pyspark.sql import SparkSession

class KeyedTable(BaseTable):
    """
    Represents a dataset with defined business and primary keys.

    Automatically:
      - Checks for duplicate primary keys
      - Generates SHA2-256 hash primary key (if not present)
      - Adds ingestion and effectivity metadata fields

    Transform function
      - Used to for mapping to target schema
      - Modifying field types, doing calculations that need to be materialised etc.
    
    Deduplication function
      - This should be used to identify if there is duplicate record (based of the business keys/primary key) 
        within a source and create a mapping between these fields ie: recordA and recordB map to recordC

    

    Example:
        customers_table = KeyedTable(
            name="customers",
            df=customers_df,
            business_keys=["locationcode", "country"],
            source_primary_keys=["customerid", "source_system", "company"],
            source_foreign_keys=[{"location": ["locationcode", "source_system", "company"]}]
            transform=None,
            deduplicate=None
        )
    """

    def __init__(
        self,
        target_db: str,
        target_schema: str,
        name: str,
        schema_evolution: bool,
        df: DataFrame,
        target_path: str,
        business_keys: List[str],
        source_primary_keys: List[str],
        source_foreign_keys: List[str],
        transform: Callable,
        deduplicate: Callable
    ):
        super().__init__(name, TableType.KEYED, df, schema_evolution=schema_evolution, target_path=target_path, target_db=target_db, target_schema=target_schema)
        self.business_keys = business_keys
        self.source_primary_keys = source_primary_keys
        self.source_foreign_keys = source_foreign_keys
        self.transform = transform
        self.deduplicate = deduplicate

    def prepare(self) -> DataFrame:
        """
        Prepare the keyed dataset for ingestion:
        - Generate primary key hash if missing
        - Check for duplicates on primary key hash
        - Add standard metadata fields
        """
        df = self.df

        # transform the dataframe
        if self.transform is not None:
            df = self.transform(df)

        # Checking source primary keys
        for key in self.source_primary_keys:
            if key not in df.columns:
                raise ValueError(f"Source primary key column '{key}' not found in DataFrame")

        # Generate a composite SHA2-256 primary key if multiple columns exist
        if len(self.source_primary_keys) > 1:
            concat_expr = F.concat_ws("||", *[F.col(k).cast("string") for k in self.source_primary_keys])
        else:
            concat_expr = F.col(self.source_primary_keys[0]).cast("string")

        # Generate the hash primary key
        df = df.withColumn(f"{self.name}_source_hk", F.sha2(F.concat_ws("||", concat_expr), 256))

        # Generate the hash foreign keys
        for mapping in self.source_foreign_keys:
            for table_name, cols in mapping.items():
                try:
                    df = df.withColumn(
                        f"{table_name}_source_fk",
                        F.sha2(F.concat_ws("|", *[F.col(c) for c in cols]), 256)
                    )
                except:
                    print(f"WARNING: One of the Foreign Key columns {cols} doesn't exist in the table")

        #  Deduplicate 
        if self.deduplicate is not None:
            df = df.withColumn("ingestion_timestamp", F.current_timestamp())
            df = self.deduplicate(df)
        else:
            # Add metadata fields
            df = add_ingestion_metadata(df, True)


        # rename the company field so it is less confusing with the SCD2 information.
        df = df.withColumnRenamed("company", "originating_company")

        # Check that there are no duplicates in the table, raises exception if there is
        assert_no_duplicate_active_records(df, "effectivity_end_date", [f"{self.name}_hk", "effectivity_end_date"])

        self.df = df
        return self.df
    
    def get_partition_keys(self):
        return self.business_keys

    def write_ingestion_log(self, df_log):
        pass

    def set_tbl_properties(self):
        self.spark.sql(f"""
            ALTER TABLE {self.target_schema}.{self.target_db}.{self.name}
            SET TBLPROPERTIES (
            'primaryKey' = '{self.name}_hk',
            'businessKeys' = '{','.join(self.business_keys)}',
            'lastUpdatedBy' = 'FabricPipeline'
            )
            """)
    
    def apply_scd_type2(self, existing_df: DataFrame, incoming_df: DataFrame) -> DataFrame:
        """
        Apply Slowly Changing Dimension (SCD Type 2) logic.
        
        APPEND:
            - return changed (end-dated existing)
            - return new rows only
        
        OVERWRITE:
            - return unchanged existing
            - return new rows
        """

        current_ts = F.current_timestamp()
        hk_col = f"{self.name}_hk"

        # Outer join to detect unchanged, changed, and new
        joined = (
            existing_df.alias("existing")
            .join(
                incoming_df.alias("incoming"),
                on=[existing_df[hk_col] == incoming_df[hk_col]],
                how="outer"
            )
        )



        # Columns excluded from change detection
        excluded = {hk_col, "effectivity_start_date", "effectivity_end_date", "ingestion_timestamp"}

        change_expr = " OR ".join([
            f"existing.{c} != incoming.{c}"
            for c in incoming_df.columns if c not in excluded
        ]) or "false"

        changed = F.expr(change_expr)

        # 1️⃣ UPDATED EXISTING → only for APPEND mode
        updated_existing = (
            joined
            .where(changed & F.col(f"existing.{hk_col}").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in existing_df.columns])
            .withColumn("effectivity_end_date", current_ts)
        )

        # 2️⃣ UNCHANGED EXISTING → only for OVERWRITE mode
        unchanged = (
            joined
            .where(~changed & F.col(f"existing.{hk_col}").isNotNull())
            .select(*[F.col(f"existing.{c}") for c in existing_df.columns])
        )

        # 3️⃣ NEW INCOMING ROWS
        new_records = (
            joined
            .where(F.col(f"existing.{hk_col}").isNull())
            .select(*[F.col(f"incoming.{c}") for c in incoming_df.columns])
            .withColumn(
                "effectivity_start_date",
                F.when(
                    F.col("incoming.effectivity_start_date").isNotNull(),
                    F.col("incoming.effectivity_start_date")
                ).otherwise(current_ts)
            )
            .withColumn("effectivity_end_date", F.lit(None).cast("timestamp"))
        )

        # 4️⃣ NEW VERSION OF CHANGED RECORDS (updated row)
        new_versions = (
            joined
            .where(changed & F.col(f"existing.{hk_col}").isNotNull())
            .select(*[F.col(f"incoming.{c}") for c in incoming_df.columns])
            .withColumn("effectivity_start_date", current_ts)
            .withColumn("effectivity_end_date", F.lit(None).cast("timestamp"))
        )
        
        # 4️⃣ FINAL RETURN LOGIC
        if self.write_method == "append":
            # Only changed + new
            return updated_existing.unionByName(new_versions).unionByName(new_records)

        else:  # overwrite
            # Only unchanged + new
            return unchanged.unionByName(new_versions).unionByName(new_records)
