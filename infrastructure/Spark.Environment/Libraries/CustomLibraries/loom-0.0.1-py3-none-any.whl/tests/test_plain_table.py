import pytest
from unittest.mock import MagicMock, patch
from loom.tables.plain_table import PlainTable


@pytest.fixture
def mock_df():
    """Create a mock Spark DataFrame with expected behavior."""
    df = MagicMock(name="MockDataFrame")

    # Simulate DataFrame columns
    df.columns = ["id", "name"]

    # Chainable withColumn() calls return the same mock DataFrame
    df.withColumn.return_value = df

    return df


@patch("loom.tables.plain_table.add_ingestion_metadata")
def test_prepare_adds_metadata_and_source_fields(mock_add_metadata, mock_df):
    """
    Test that PlainTable.prepare() validates schema, 
    adds source_system/entity columns, 
    and calls add_ingestion_metadata.
    """
    # Arrange
    mock_add_metadata.return_value = mock_df  # pretend metadata returns same df


    table = PlainTable(
        target_schema="dbo",
        target_db="public",
        name="customers_raw",
        source_system="SystemX",
        df=mock_df,
        target_path="/tmp/publc/customers_raw",
        write_method="overwrite",
        cleanse_function=None
    )

    # Act
    result_df = table.prepare()

    # Assert
    # --- validation didn't raise
    assert result_df is mock_df

    # --- should call withColumn twice (for source_system )
    assert mock_df.withColumn.call_count >= 1


    # --- should call add_ingestion_metadata once
    mock_add_metadata.assert_called_once_with(mock_df, False)


def test_prepare_raises_if_no_columns():
    """Test that prepare() raises ValueError if the DataFrame has no columns."""
    mock_df = MagicMock()
    mock_df.columns = []  # Empty schema

    table = PlainTable(
        target_schema="dbo",
        target_db="public",
        name="empty_table",
        source_system="Sys",
        df=mock_df,
        target_path="/tmp/public/empty",
        write_method="append",
        cleanse_function=None
    )

    with pytest.raises(ValueError, match="has no columns defined"):
        table.prepare()
