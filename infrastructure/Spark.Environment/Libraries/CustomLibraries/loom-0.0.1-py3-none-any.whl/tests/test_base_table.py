import pytest
from unittest.mock import MagicMock, patch
from loom.tables.base_table import BaseTable
from loom.tables.table_type import TableType


# ---- Dummy subclass so we can instantiate BaseTable ---- #
class DummyTable(BaseTable):
    def prepare(self):
        return self.df

    def set_tbl_properties(self):
        pass

    def get_partition_keys(self):
        return []
    
    def write_ingestion_log(self):
        pass

    def apply_scd_type2(self):
        pass

# ---- Fixtures ---- #
@pytest.fixture
def mock_df():
    df = MagicMock()
    df.columns = ["id", "name"]
    df.show.return_value = None
    df.printSchema.return_value = None
    df.count.return_value = 42
    df.cache.return_value = df
    df.write = MagicMock()
    return df


@pytest.fixture
def base_table(mock_df):
    return DummyTable(
        target_schema="dbo",
        target_db="sales",
        name="customers",
        table_type=TableType.PLAIN,
        df=mock_df,
        target_path="/tmp/test_table",
        format="delta",
        schema_evolution=True,
        write_method="overwrite"
    )


# ---- Tests ---- #
def test_validate_schema_valid(base_table):
    # Should not raise
    base_table.validate_schema()


def test_validate_schema_raises_no_df():
    table = DummyTable(target_schema="dbo",target_db="sales", name="x", table_type=TableType.PLAIN, df=None)
    with pytest.raises(ValueError, match="has no DataFrame assigned"):
        table.validate_schema()


def test_validate_schema_raises_empty_columns(mock_df):
    mock_df.columns = []
    table = DummyTable(target_schema="dbo",target_db="sales", name="x", table_type=TableType.PLAIN, df=mock_df)
    with pytest.raises(ValueError, match="has no columns"):
        table.validate_schema()


def test_show_schema_calls_printSchema(base_table, mock_df):
    base_table.show_schema()
    mock_df.printSchema.assert_called_once()


def test_preview_calls_show(base_table, mock_df):
    base_table.preview(5)
    mock_df.show.assert_called_once_with(5)


@patch("loom.tables.base_table.os.makedirs")
@patch("loom.tables.base_table.SparkSession")
def test_write_applies_scd_type2_if_keyed(mock_spark, mock_df):
    mock_spark.builder.getOrCreate.return_value = MagicMock()
    table = DummyTable(
        target_schema="dbo",
        target_db="s",
        name="t",
        table_type=TableType.KEYED,
        df=mock_df,
        target_path="/tmp/test",
        format="delta"
    )
    table.apply_scd_type2 = MagicMock(return_value=mock_df)
    table.spark.read.format().load.side_effect = Exception("No existing data")

    table.write()

    table.apply_scd_type2.assert_called() 
    mock_df.write.format.assert_called_once()


def test_count_returns_value(base_table):
    assert base_table.count() == 42


def test_cache_returns_df_and_calls_cache(base_table, mock_df):
    result = base_table.cache()
    mock_df.cache.assert_called_once()
    assert result == mock_df
