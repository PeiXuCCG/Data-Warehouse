import pytest
from unittest.mock import patch
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import StructType, StructField, StringType
from loom.tables.keyed_table import KeyedTable
from pyspark.sql.functions import sha2, lit


@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("KeyedTableTest").getOrCreate()


def deduplicate_customers(df):
    # Example deduplication logic — just mark duplicates with a dummy hash for testing
    return df.withColumn("customers_hk", sha2(F.concat_ws("||", F.lit("-1")), 256))


def test_prepare_adds_hash_and_metadata(spark):
    # Create a simple input DataFrame
    df = spark.createDataFrame(
        [
            (1, "Alice", "VIC", "SystemY", "CompanyA"),
            (2, "Bob", "NSW", "SystemX", "CompanyB"),
        ],
        ["customerid", "name", "locationcode", "source_system", "company"]
    )

    # Mock add_ingestion_metadata and assert_no_duplicates
    with patch("loom.tables.keyed_table.add_ingestion_metadata", side_effect=lambda df, _: df) as mock_meta, \
         patch("loom.tables.keyed_table.assert_no_duplicates") as mock_dupes:
        
        table = KeyedTable(
            target_db="public",
            target_schema="dbo",
            name="customers",
            schema_evolution=False,
            df=df,
            target_path="/tmp",
            business_keys=["customerid"],
            source_primary_keys=["customerid", "source_system", "company"],
            source_foreign_keys=[{"location": ["locationcode", "source_system", "company"]}],
            transform=None,
            deduplicate=deduplicate_customers
        )

        result_df = table.prepare()
        columns = result_df.columns

        # Check primary key hash added
        assert "customers_source_hk" in columns

        # Verify mocks called
        mock_meta.assert_called_once()
        mock_dupes.assert_called_once()

        # Ensure all rows still exist
        assert result_df.count() == df.count()


def test_prepare_raises_for_missing_primary_key(spark):
    df = spark.createDataFrame(
        [(1, "Alice")],
        ["WrongID", "Name"]
    )

    table = KeyedTable(
        target_schema="dbo",
        target_db="public",
        name="customers",
        schema_evolution=False,
        df=df,
        target_path="/tmp",
        business_keys=["WrongID"],
        source_primary_keys=["customerid"],  # missing in DF
        source_foreign_keys=[],
        transform=None,
        deduplicate=None
    )

    with pytest.raises(ValueError, match="Source primary key column 'customerid' not found"):
        table.prepare()


def test_apply_scd_type2_handles_changes(spark):
    # Define explicit schemas for both DataFrames
    existing_schema = StructType([
        StructField("customers_hk", StringType(), False),
        StructField("Name", StringType(), True),
        StructField("effectivity_start_date", StringType(), True),
        StructField("effectivity_end_date", StringType(), True),
    ])

    incoming_schema = StructType([
        StructField("customers_hk", StringType(), False),
        StructField("Name", StringType(), True),
    ])

    # Create typed DataFrames
    existing_df = spark.createDataFrame(
        [
            ("1", "Alice", "2024-01-01", None),
            ("2", "Bob", "2024-01-01", None),
        ],
        schema=existing_schema
    )

    incoming_df = spark.createDataFrame(
        [
            ("1", "Alicia"),   # Changed name
            ("2", "Bob"),      # Unchanged
            ("3", "Charlie"),  # New record
        ],
        schema=incoming_schema
    )

    table = KeyedTable(
        target_schema="dbo",
        target_db="public",
        name="customers",
        schema_evolution=False,
        df=incoming_df,
        target_path="/tmp",
        business_keys=["locationcode", "state"],
        source_primary_keys=["customerid"],
        source_foreign_keys=[],
        transform=None,
        deduplicate=deduplicate_customers
    )

    result = table.apply_scd_type2(existing_df, incoming_df)

    # Basic column presence check
    assert "effectivity_start_date" in result.columns
    assert "effectivity_end_date" in result.columns

    # Collect results for verification
    result_data = [r.asDict() for r in result.collect()]

    # Alicia should appear (updated record)
    assert any(r.get("Name") == "Alicia" for r in result_data)
    # Charlie should appear (new record)
    assert any(r.get("Name") == "Charlie" for r in result_data)
    # At least one record should be end-dated
    assert any(r.get("effectivity_end_date") is not None for r in result_data)
