# -*- coding: utf-8 -*-
"""
Loom — Data ingestion and transformation framework for Microsoft Fabric (PySpark-based).
This package provides structured abstractions for working with data tables,
pipelines, and utilities to streamline ingestion, transformation, and delta management.
"""

__version__ = "0.0.1"

# Core subpackages
from .tables import *
from .pipelines import *
from .utils import *

# Optional: explicit exports (good for linting and autocomplete)
__all__ = [
    "tables",
    "pipelines",
    "utils",
]
