"""
Loom Tables package.
Contains table abstractions such as PlainTable, KeyedTable, and MasterLinkedTable.
"""

from .base_table import BaseTable
from .plain_table import PlainTable
from .keyed_table import KeyedTable
from .master_linked_table import MasterLinkedTable

__all__ = [
    "BaseTable",
    "PlainTable",
    "KeyedTable",
    "MasterLinkedTable",
]
