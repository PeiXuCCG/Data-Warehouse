from enum import Enum


class TableType(Enum):
    PLAIN = 1,
    KEYED = 2,
    MASTERLINKED = 3