import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# Create figure
fig, ax = plt.subplots(figsize=(10, 8))
ax.axis('off')

# Define box positions and styles
boxes = [
    ("Source Data\n(API, CSV, Parquet)", (0.5, 0.92), "#f4d03f"),
    ("PlainTable\n(Raw Zone)\n- Lightweight ingestion\n- Add metadata", (0.5, 0.75), "#85c1e9"),
    ("KeyedTable\n(Bronze Zone)\n- Add keys, deduplicate\n- Generate SHA2 hash", (0.5, 0.55), "#82e0aa"),
    ("MasterLinkedTable\n(Silver Zone)\n- Join master data\n- Enrich with descriptions", (0.5, 0.35), "#f5b7b1"),
    ("Curated / Gold Zone\n- Business-ready models\n- Power BI / Analytics", (0.5, 0.15), "#d7bde2")
]

# Draw boxes
for text, (x, y), color in boxes:
    ax.add_patch(mpatches.FancyBboxPatch(
        (x - 0.25, y - 0.07), 0.5, 0.12,
        boxstyle="round,pad=0.02", fc=color, ec="black", lw=1.5
    ))
    ax.text(x, y, text, ha='center', va='center', fontsize=10, weight='bold')

# Draw arrows
arrow_props = dict(facecolor='black', arrowstyle='->', lw=1.5)
for i in range(len(boxes) - 1):
    ax.annotate('', xy=(0.5, boxes[i + 1][1][1] + 0.05),
                xytext=(0.5, boxes[i][1][1] - 0.05),
                arrowprops=arrow_props)

plt.title("LOOM Data Ingestion Flow: Source → Raw → Bronze → Silver → Gold", 
          fontsize=12, weight='bold')
plt.show()
