# %%
from pyspark.sql import SparkSession
from loom.tables.keyed_table import KeyedTable
from loom.pipelines import Pipeline
from pyspark.sql.functions import col, sha2

# %%
# 1. Initialize Spark session
spark = SparkSession.builder.appName("LoomKeyedExample").getOrCreate()

# %%
# 2. Define transform logic for KeyedTable
def customer_transform(df):
    """
    Example transformation:
      - Rename columns
      - Add derived columns
      - Filter invalid records
    """
    return (
        df
        .withColumnRenamed("CustomerID", "customerid")
        .withColumnRenamed("CustomerName", "customername")
        .filter(df["CustomerID"].isNotNull())
    )

# %%
def customer_deduplicate(df):

    df = df.withColumn(
        "customer_hk",
        sha2(col("customername"), 256)
    )

    return df

# %%
df = spark.read.table("dbo.customers_raw")

# %%
# 4. Create the curated keyed table
customers_curated =  table = KeyedTable(
            target_db="public",
            target_schema="dbo",
            name="customers",
            schema_evolution=False,
            df=df,
            target_path="/tmp",
            business_keys=["customerid"],
            source_primary_keys=["customerid", "source_system", "company"],
            source_foreign_keys=[{"location": ["locationcode", "source_system", "company"]}],
            transform=customer_transform,
            deduplicate=customer_deduplicate
)

# %%
# 5. Build the pipeline
customer_pipeline = Pipeline(
    name="customer_pipeline",
    tables=[customers_curated],
    dry_run=True,   # simulate execution without writing
)

# %%
# 6. Execute the pipeline
customer_pipeline.summary()   # Prints info about each table
customer_pipeline.validate()  # Validates structure and metadata
customer_pipeline.execute()   # Runs the prepare + write steps
