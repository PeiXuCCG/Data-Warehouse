#!/usr/bin/env python
# coding: utf-8

# ## Source_To_Raw.py
# 
# New notebook

# In[10]:


from pyspark.sql import SparkSession
from loom.tables.table_type  import TableType
from loom.tables.plain_table import PlainTable
from loom.pipelines import Pipeline
from notebookutils import mssparkutils
import sys
# In[ ]:
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite","LEGACY")

# In[ ]:
target_schema = "ccg_bronze"
target_db =  "raw" 
source_system = "SystemX"
source_entity = "EntityY"
target_table = f"object"
source_path = 'Files/deltas/object'
is_multi_line = True
pipeline_name = f"{source_system}_{target_table}"


# In[ ]:


spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{target_schema}`.`{target_db}`")


# In[ ]:
ingestion_log = "dbo.ingestion_log"
pipelines = []

# In[ ]:


def cleanse(df):
    #remove spaces
    pattern = r"[^a-z_]+" 
    new_columns = [re.sub(pattern, "", col_name) for col_name in df.columns]
    df_cleaned = df.toDF(*new_columns)
    return df_cleaned


# In[ ]:
# Prevent duplicate loads
files = [f.path for f in mssparkutils.fs.ls(source_path) if f.name.endswith(".csv")]

# Step 2: Read existing file log
log_df = None
if spark.catalog.tableExists(ingestion_log):
    log_df = spark.read.table(ingestion_log)
    print("Table loaded successfully.")
else:
    print(f"Table {ingestion_log} does not exist.")

if log_df is not None:
    loaded_files = [r["filename"] for r in log_df.collect()]

    # Step 3: Filter new files
    new_files = [f for f in files if f not in loaded_files]
else:
    # Step 3: first load
    new_files = files

if not new_files:
    print("✅ No new files to load, exit")
    sys.exit()
else:
    print(f"📂 Loading {len(new_files)} new files...")

# In[ ]:
df = spark.read.option("header", True).option("inferSchema", True).option("multiLine", is_multi_line).csv(new_files)

# In[ ]:


customers_raw = PlainTable(
    target_db=target_db,
    target_schema=target_schema,
    name=target_table,
    df=df,
    source_system=source_system,
    target_path="NOT_SUPPORTED_YET", # this is technically not used due to fabric not supporting it but leave it here
    write_method="overwrite",
    cleanse_function=cleanse
)


# In[ ]:


pipeline = Pipeline(
    name=pipeline_name,
    tables=[customers_raw],
    dry_run=False,  # Set to True to simulate without writing
    target_schema=target_schema,
    target_db="dbo"
)

pipelines.append(pipeline)



# In[ ]:


for p in pipelines:
    p.summary()
    p.validate()
    p.execute()

