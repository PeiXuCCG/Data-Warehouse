#!/usr/bin/env python
# coding: utf-8

# ## Master_Linked_Demo.py
# 
# Demonstration of linking base data with master data using MasterLinkedTable
# and applying SCD Type 2 logic.

# In[1]:

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from typing import List, Tuple, Callable
from tables  import MasterLinkedTable
from loom.pipelines import Pipeline
import sys

# In[2]:
spark = SparkSession.builder.appName("MasterLinkedTableDemo").getOrCreate()
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "LEGACY")

# In[3]:
target_schema = "ccg_silver"
target_db = "raw"
target_table = "sales_order_line"
pipeline_name = f"master_link_{target_table}"
is_multi_line = True

# In[4]:
spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{target_schema}`.`{target_db}`")

# In[7]:
# Mock product master and sales data
product_master_df = spark.createDataFrame([
    ("P001", "Widget", "Active"),
    ("P002", "Gadget", "Active"),
], ["productcode", "product_name", "status"]) \
.withColumn("product_hk", F.sha2(F.col("productcode"), 256)) \
.withColumn("product_source_hk", F.sha2(F.concat_ws("|", F.col("productcode"), F.lit("source")), 256))

salesorderheader_df = spark.read.table("dbo.salesorderheader")


# In[8]:
# Define master link relationships
master_links = [
    ("product_master_hk", product_master_df, "productcode", "product_hk", [{"ProductName": "product_name"}])
]

# In[ ]:
pipelines = []

# In[9]:
# Instantiate MasterLinkedTable and prepare data
sales_table = MasterLinkedTable(
    name=target_table,
    df=salesorderheader_df,
    schema_evolution=True,
    target_path="", #Not supported in Fabric
    target_db=target_db,
    target_schema=target_schema,
    business_keys=["product"],
    primary_key=["salesorder_hk"],
    master_links=master_links
)


# In[12]:
pipeline = Pipeline(
    name=pipeline_name,
    tables=[sales_table],
    dry_run=False,  # Set to True to simulate without writing
    target_schema=target_schema,
    target_db="dbo"
)

pipelines.append(pipeline)

# In[12]:
for p in pipelines:
    p.summary()
    p.validate()
    p.execute()

# In[12]:
print("✅ MasterLinkedTable demo completed successfully.")
