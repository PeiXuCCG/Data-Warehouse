# What is Loom?
Loom is a lightweight, flexible data ingestion and transformation framework built on PySpark for Microsoft Fabric Lakehouse or any Spark-based data warehouse.
It provides a consistent, declarative way to define tables, handle keys, add metadata automatically, and run data pipelines — all from Python notebooks.
Think of it as a structured data loader and schema enforcer that sits between raw data and curated warehouse layers.

# Why Loom is Useful
Loom simplifies the process of ingesting, transforming, and managing data in a Microsoft Fabric Lakehouse by providing a consistent, declarative framework. Instead of writing repetitive Spark code for every dataset, you can define data sources, keys, and transformations once — and Loom takes care of batch tracking,  metadata management automatically. This makes data pipelines easier to maintain, more reliable, and faster to deploy across multiple business domains such as customers, products, and sales.

Beyond ingestion, Loom enforces structure and governance across all layers of your data warehouse. It standardizes how effectivity dates, ingestion timestamps, and primary keys are handled, ensuring that every dataset is auditable and aligned with enterprise data modeling best practices. Whether you’re building dimensions, facts, or master data mappings, Loom helps maintain consistency, improve data quality, and reduce engineering overhead.

# Table Types
PlainTable - Used for raw/staging data — no keys or metadata.
KeyedTable - Used for data with defined business and primary keys
MasterLinkedTable - Used for data linked to a master data entity (e.g. product), 
**** IMPORTANT *****
You will need to provide the path to the master data to join to.

# How to build the wheel package
From the root of your project run the following.
pip3  install build setuptools wheel
python setup.py sdist bdist_wheel

# Installation
Once you have the Loom wheel file (e.g. loom-0.0.1-py3-none-any.whl), you can install it in your Fabric or Spark environment by us following instructions:

https://fabric.guru/installing-custom-python-packages-in-fabric#heading-installing-wheel-in-the-workspace

OR

pip install loom-0.0.1-py3-none-any.whl

IF published to a repository:
pip install loom


# How to use Loom
Review the example_plain.py or example_keyed.py in the example folder.

# How to run unit tests
pip3 install -e .
pytest tests/

# Future Enhancements
* Data Type enforcement
* Improved unit tests
* Allow for different types of Data Models (Data Vault)
