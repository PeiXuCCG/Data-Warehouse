import pytest
from unittest.mock import MagicMock, patch
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import StructType, StructField, StringType
from loom.tables.keyed_table import KeyedTable
from pyspark.sql.functions import sha2, lit


@pytest.fixture(scope="module")
def spark():
    return SparkSession.builder.master("local[1]").appName("KeyedTableTest").getOrCreate()


def deduplicate_customers(df):
    return df.withColumn("customers_hk", sha2(F.concat_ws("||", F.col("name")), 256))


def test_prepare_adds_hash_and_metadata(spark):
    # Create a simple input DataFrame
    df = spark.createDataFrame(
        [
            (1, "Alice", "VIC", "SystemY", "CompanyA"),
            (2, "Bob", "NSW", "SystemX", "CompanyB"),
        ],
        ["customerid", "name", "locationcode", "source_system", "company"]
    )

    # Mock add_ingestion_metadata and assert_no_duplicates
    with patch("loom.tables.keyed_table.add_ingestion_metadata", side_effect=lambda df, _: df) as mock_meta, \
         patch("loom.tables.keyed_table.assert_no_duplicate_active_records") as mock_dupes:
        
        table = KeyedTable(
            target_db="public",
            target_schema="dbo",
            name="customers",
            schema_evolution=False,
            df=df,
            target_path="/tmp",
            business_keys=["customerid"],
            source_primary_keys=["customerid", "source_system", "company"],
            source_foreign_keys=[{"location": ["locationcode", "source_system", "company"]}],
            transform=None,
            deduplicate=deduplicate_customers
        )

        result_df = table.prepare()
        columns = result_df.columns

        # Check primary key hash added
        assert "customers_hk" in columns

        # Verify mocks called
        if  mock_dupes.called:
            mock_dupes.assert_called_once()
        else:
            mock_meta.assert_called_once()

        # Ensure all rows still exist
        assert result_df.count() == df.count()


def test_prepare_raises_for_missing_primary_key(spark):
    df = spark.createDataFrame(
        [(1, "Alice")],
        ["WrongID", "Name"]
    )

    table = KeyedTable(
        target_schema="dbo",
        target_db="public",
        name="customers",
        schema_evolution=False,
        df=df,
        target_path="/tmp",
        business_keys=["WrongID"],
        source_primary_keys=["customerid"],  # missing in DF
        source_foreign_keys=[],
        transform=None,
        deduplicate=None
    )

    with pytest.raises(ValueError, match="Source primary key column 'customerid' not found"):
        table.prepare()


def test_apply_scd_type2_handles_changes(spark):
    incoming_schema = StructType([
        StructField("customers_hk", StringType(), False),
        StructField("Name", StringType(), True),
        StructField("effectivity_start_date", StringType(), True),
        StructField("effectivity_end_date", StringType(), True),
    ])

    incoming_df = spark.createDataFrame(
        [
            ("1", "Alicia", "2025-01-01", None),
            ("2", "Bob", "2023-01-01", None),
            ("3", "Charlie", "2023-01-01", None),
        ],
        schema=incoming_schema
    )

    table = KeyedTable(
        target_schema="dbo",
        target_db="public",
        name="customers",
        schema_evolution=False,
        df=incoming_df,
        target_path="/tmp",
        business_keys=["customers_hk"],
        source_primary_keys=["customers_hk"],
        source_foreign_keys=[],
        transform=None,
        deduplicate=deduplicate_customers
    )

    # -----------------------
    # Patch DeltaTable
    # -----------------------
    mock_delta_table = MagicMock()
    mock_delta_table.alias.return_value = mock_delta_table
    mock_delta_table.merge.return_value = mock_delta_table
    mock_delta_table.whenMatchedUpdate.return_value = mock_delta_table
    mock_delta_table.whenNotMatchedInsertAll.return_value = mock_delta_table
    mock_delta_table.execute.return_value = None

    # Patch bad_target.count() > 0 path
    bad_df = MagicMock()
    bad_df.limit.return_value.count.return_value = 0  # No bad rows, prevents RuntimeError

    hk_col = "customers_hk"
    mock_delta_table.toDF.return_value \
        .filter.return_value \
        .groupBy.return_value \
        .count.return_value \
        .filter.return_value = bad_df

    with patch(
        "delta.tables.DeltaTable.forName",
        return_value=mock_delta_table
    ):
        table.apply_scd_type2(incoming_df)

    assert mock_delta_table.merge.called




