from setuptools import setup, find_packages

setup(
    name="data_cleaning_rules",
    version="0.0.1",
    description="Data cleansing and transformation framework for Microsoft Fabric built on PySpark",
    author="Priyabrata Sahu",
    author_email="",  # optional, you can add one here if desired
    url="https://www.excopartners.com",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "pyspark>=3.5.0",
        "pytest>=8.0.0",
        "delta-spark>=3.0.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
